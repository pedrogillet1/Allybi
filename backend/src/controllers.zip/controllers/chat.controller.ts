/**
 * Chat Controller V1
 *
 * Clean REST API endpoints for chat functionality.
 * Single AI surface - all chat interactions go through orchestrator.
 */

import { Request, Response } from 'express';
import chatService from '../services/chat.service';
import prisma from '../config/database';
import { getContainer } from '../bootstrap/container';
// Title generation disabled for certification - avoids OpenAI runtime dependency
// import { generateConversationTitle } from '../services/openai.service';
import { OrchestratorRequest } from '../services/core/kodaOrchestratorV3.service';
import { LanguageCode } from '../types/intentV3.types';
import { loadUnifiedContext, buildOrchestratorContext } from '../services/conversationUnifiedContext.service';
import { getConversationContextService } from '../services/conversationContext.service';
// cacheService now accessed via getContainer().getCache()

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Ensure conversation exists before creating messages
 */
async function ensureConversationExists(conversationId: string, userId: string) {
  let conversation = await prisma.conversation.findUnique({
    where: { id: conversationId },
  });

  if (!conversation) {
    console.log(`[Chat] Creating conversation ${conversationId}`);
    conversation = await prisma.conversation.create({
      data: {
        id: conversationId,
        userId,
        title: 'New Chat',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    });
  }

  return conversation;
}

// ============================================================================
// Conversation Endpoints
// ============================================================================

/**
 * POST /api/chat/conversations
 * Create a new conversation
 */
export const createConversation = async (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const { title } = req.body;

    const conversation = await chatService.createConversation({
      userId,
      title,
    });

    res.status(201).json(conversation);
  } catch (error: any) {
    console.error('[Chat] Create conversation error:', error);
    res.status(500).json({ error: error.message });
  }
};

/**
 * GET /api/chat/conversations
 * Get all conversations for user
 */
export const getConversations = async (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;

    // Try cache first
    const cacheKey = getContainer().getCache().generateKey('conversations_list', userId);
    const cached = await getContainer().getCache().get<any>(cacheKey);

    if (cached) {
      res.json(cached);
      return;
    }

    const conversations = await chatService.getUserConversations(userId);

    // Cache for 2 minutes
    await getContainer().getCache().set(cacheKey, conversations, { ttl: 120 });

    res.json(conversations);
  } catch (error: any) {
    console.error('[Chat] Get conversations error:', error);
    res.status(500).json({ error: error.message });
  }
};

/**
 * GET /api/chat/conversations/:conversationId
 * Get single conversation with messages
 */
export const getConversation = async (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const { conversationId } = req.params;

    // Try cache first
    const cacheKey = getContainer().getCache().generateKey('conversation', conversationId, userId);
    const cached = await getContainer().getCache().get<any>(cacheKey);

    if (cached) {
      res.json(cached);
      return;
    }

    const conversation = await chatService.getConversation(conversationId, userId);

    // Cache for 1 minute
    await getContainer().getCache().set(cacheKey, conversation, { ttl: 60 });

    res.json(conversation);
  } catch (error: any) {
    console.error('[Chat] Get conversation error:', error);
    if (error.message === 'Conversation not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
};

/**
 * DELETE /api/chat/conversations/:conversationId
 * Delete a conversation
 */
export const deleteConversation = async (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const { conversationId } = req.params;

    await chatService.deleteConversation(conversationId, userId);

    // Invalidate caches
    const cacheKey = getContainer().getCache().generateKey('conversation', conversationId, userId);
    const listCacheKey = getContainer().getCache().generateKey('conversations_list', userId);
    await getContainer().getCache().set(cacheKey, null, { ttl: 0 });
    await getContainer().getCache().set(listCacheKey, null, { ttl: 0 });

    res.json({ success: true });
  } catch (error: any) {
    console.error('[Chat] Delete conversation error:', error);
    if (error.message === 'Conversation not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
};

/**
 * DELETE /api/chat/conversations
 * Delete all conversations for user
 */
export const deleteAllConversations = async (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;

    const result = await chatService.deleteAllConversations(userId);

    // Invalidate cache
    const listCacheKey = getContainer().getCache().generateKey('conversations_list', userId);
    await getContainer().getCache().set(listCacheKey, null, { ttl: 0 });

    res.json(result);
  } catch (error: any) {
    console.error('[Chat] Delete all conversations error:', error);
    res.status(500).json({ error: error.message });
  }
};

// ============================================================================
// Message Endpoints
// ============================================================================

/**
 * POST /api/chat/conversations/:conversationId/messages
 * Send a message
 */
export const sendMessage = async (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const { conversationId } = req.params;
    const { content, attachedDocumentId } = req.body;

    if (!content) {
      res.status(400).json({ error: 'Content is required' });
      return;
    }

    const result = await chatService.sendMessage({
      userId,
      conversationId,
      content,
      attachedDocumentId,
    });

    // Invalidate cache
    const cacheKey = getContainer().getCache().generateKey('conversation', conversationId, userId);
    await getContainer().getCache().set(cacheKey, null, { ttl: 0 });

    res.json(result);
  } catch (error: any) {
    console.error('[Chat] Send message error:', error);
    res.status(500).json({ error: error.message });
  }
};

/**
 * GET /api/chat/conversations/:conversationId/messages
 * Get messages for a conversation
 */
export const getMessages = async (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const { conversationId } = req.params;

    // Verify access
    const conversation = await prisma.conversation.findFirst({
      where: { id: conversationId, userId },
    });

    if (!conversation) {
      res.status(404).json({ error: 'Conversation not found' });
      return;
    }

    const messages = await prisma.message.findMany({
      where: { conversationId },
      orderBy: { createdAt: 'asc' },
    });

    res.json(messages);
  } catch (error: any) {
    console.error('[Chat] Get messages error:', error);
    res.status(500).json({ error: error.message });
  }
};

// ============================================================================
// Utility Endpoints
// ============================================================================

/**
 * POST /api/chat/regenerate-titles
 * Regenerate conversation titles
 */
export const regenerateTitles = async (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;

    const result = await chatService.regenerateConversationTitles(userId);

    res.json(result);
  } catch (error: any) {
    console.error('[Chat] Regenerate titles error:', error);
    res.status(500).json({ error: error.message });
  }
};

// ============================================================================
// Streaming Endpoint (Single AI Surface)
// ============================================================================

/**
 * POST /api/chat/conversations/:conversationId/messages/stream
 * Send a message with SSE streaming response.
 *
 * This is the single AI surface - all chat interactions go through the orchestrator.
 * No body mutation, no delegation to other controllers.
 */
export const sendMessageStream = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  try {
    const userId = req.user?.id;
    if (!userId) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }

    const { conversationId } = req.params;
    const { content, language = 'en' } = req.body;

    if (!content || !conversationId) {
      res.status(400).json({ error: 'Content and conversationId are required' });
      return;
    }

    // Load unified context (combines DB + memory)
    const unifiedContext = await loadUnifiedContext(prisma, conversationId, userId);

    console.log(`\n${'═'.repeat(70)}`);
    console.log(`[CHAT-STREAM] ${requestId}`);
    console.log(`├── userId: ${userId}`);
    console.log(`├── conversationId: ${conversationId}`);
    console.log(`├── content: "${content.substring(0, 60)}..."`);
    console.log(`├── docCount: ${unifiedContext.documentCount}`);
    console.log(`├── lastDocumentIds: ${unifiedContext.lastDocumentIds.length} docs`);
    console.log(`├── lastIntent: ${unifiedContext.lastIntent || 'none'}`);
    console.log(`└── timestamp: ${new Date().toISOString()}`);
    console.log(`${'═'.repeat(70)}\n`);

    // Ensure conversation exists BEFORE streaming
    await ensureConversationExists(conversationId, userId);

    // Set up SSE headers
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();

    // Create AbortController for clean cancellation
    const abortController = new AbortController();
    const { signal } = abortController;

    // Handle client disconnect
    let aborted = false;
    req.on('close', () => {
      if (!aborted) {
        aborted = true;
        abortController.abort();
        console.log('[Chat] Client disconnected, abort signal sent');
      }
    });

    const request: OrchestratorRequest = {
      userId,
      text: content,
      language: (language as LanguageCode) || 'en',
      conversationId,
      abortSignal: signal,
      context: buildOrchestratorContext(unifiedContext),
    };

    // Stream from orchestrator
    const stream = getContainer().getOrchestrator().orchestrateStream(request);

    let fullAnswer = '';
    let streamResult: any = {};
    let citations: any[] = [];

    // Process stream events
    let iterResult = await stream.next();
    while (!iterResult.done) {
      if (signal.aborted) {
        console.log('[Chat] Stream aborted by client');
        break;
      }

      const event = iterResult.value;

      if (event.type === 'content') {
        fullAnswer += (event as any).content;
        res.write(`data: ${JSON.stringify({ ...event, requestId })}\n\n`);
      } else if (event.type === 'citation') {
        citations = (event as any).citations || [];
        res.write(`data: ${JSON.stringify({ ...event, requestId })}\n\n`);
      } else if (event.type === 'done') {
        const doneEvent = event as any;
        fullAnswer = doneEvent.fullAnswer || fullAnswer;
        streamResult = {
          intent: doneEvent.intent,
          confidence: doneEvent.confidence,
          documentsUsed: doneEvent.documentsUsed,
          tokensUsed: doneEvent.tokensUsed,
          processingTime: doneEvent.processingTime,
          wasTruncated: doneEvent.wasTruncated,
          citations: doneEvent.citations || citations,
          sources: doneEvent.sources || [],
          sourceDocumentIds: doneEvent.sourceDocumentIds || [],
          formatted: doneEvent.formatted,
          attachments: doneEvent.attachments || [],
          actions: doneEvent.actions || [],
          referencedFileIds: doneEvent.referencedFileIds || [],
          sourceButtons: doneEvent.sourceButtons || null,
          fileList: doneEvent.fileList || null,
          composedBy: doneEvent.composedBy || undefined,
          operator: doneEvent.operator || undefined,
          templateId: doneEvent.templateId || undefined,
          languageDetected: doneEvent.languageDetected || undefined,
          languageLocked: doneEvent.languageLocked || undefined,
          truncationRepairApplied: doneEvent.truncationRepairApplied ?? undefined,
          docScope: doneEvent.docScope || undefined,
          scopeDocIds: doneEvent.scopeDocIds || undefined,
          anchorTypes: doneEvent.anchorTypes || undefined,
          attachmentsTypes: doneEvent.attachmentsTypes || undefined,
          trustCheck: doneEvent.trustCheck || undefined,
        };
      } else {
        res.write(`data: ${JSON.stringify({ ...event, requestId })}\n\n`);
      }

      iterResult = await stream.next();
    }

    // Capture generator return value
    if (iterResult.done && iterResult.value) {
      const returnValue = iterResult.value;
      fullAnswer = returnValue.fullAnswer || fullAnswer;
      if (!streamResult.intent) {
        streamResult = {
          ...streamResult,
          intent: returnValue.intent,
          confidence: returnValue.confidence,
          documentsUsed: returnValue.documentsUsed,
          tokensUsed: returnValue.tokensUsed,
          processingTime: returnValue.processingTime,
          wasTruncated: returnValue.wasTruncated,
          citations: returnValue.citations || citations,
        };
      }
    }

    // Skip DB writes if aborted
    if (signal.aborted) {
      console.log('[Chat] Stream aborted, skipping DB writes');
      res.end();
      return;
    }

    // Save messages AFTER streaming (TTFT optimization)
    const userMessage = await prisma.message.create({
      data: {
        conversationId,
        role: 'user',
        content,
      },
    });

    const assistantMessage = await prisma.message.create({
      data: {
        conversationId,
        role: 'assistant',
        content: fullAnswer,
        metadata: JSON.stringify({
          primaryIntent: streamResult.intent,
          confidence: streamResult.confidence,
          processingTime: streamResult.processingTime,
          documentsUsed: streamResult.documentsUsed,
          tokensUsed: streamResult.tokensUsed,
          wasTruncated: streamResult.wasTruncated,
          citations: streamResult.citations || citations,
          sourceDocumentIds: streamResult.sourceDocumentIds || [],
          attachments: streamResult.attachments || [],
          actions: streamResult.actions || [],
          referencedFileIds: streamResult.referencedFileIds || [],
        }),
      },
    });

    // Increment message count in ConversationContextStore
    await getConversationContextService(prisma).incrementMessageCount(conversationId);

    // Title generation disabled for certification - avoids OpenAI runtime dependency
    // Title can be generated client-side or via a background job if needed

    // Invalidate cache
    const cacheKey = getContainer().getCache().generateKey('conversation', conversationId, userId);
    await getContainer().getCache().set(cacheKey, null, { ttl: 0 });

    // Build constraints for frontend
    const constraints = streamResult.constraints || {};
    if ((streamResult as any).metadata?.buttonOnly) {
      constraints.buttonsOnly = true;
    }

    // Send final done event with message IDs
    res.write(
      `data: ${JSON.stringify({
        type: 'done',
        requestId,
        messageId: userMessage.id,
        assistantMessageId: assistantMessage.id,
        conversationId,
        fullAnswer,
        formatted: streamResult.formatted || fullAnswer,
        intent: streamResult.intent,
        confidence: streamResult.confidence,
        processingTime: Date.now() - startTime,
        documentsUsed: streamResult.documentsUsed,
        tokensUsed: streamResult.tokensUsed,
        wasTruncated: streamResult.wasTruncated || false,
        citations: streamResult.citations || citations,
        sources: streamResult.sources || [],
        sourceDocumentIds: streamResult.sourceDocumentIds || [],
        attachments: streamResult.attachments || [],
        actions: streamResult.actions || [],
        referencedFileIds: streamResult.referencedFileIds || [],
        sourceButtons: streamResult.sourceButtons || null,
        fileList: streamResult.fileList || null,
        constraints: Object.keys(constraints).length > 0 ? constraints : undefined,
        composedBy: streamResult.composedBy || undefined,
        operator: streamResult.operator || undefined,
        templateId: streamResult.templateId || undefined,
        languageDetected: streamResult.languageDetected || undefined,
        languageLocked: streamResult.languageLocked || undefined,
        truncationRepairApplied: streamResult.truncationRepairApplied,
        docScope: streamResult.docScope || undefined,
        scopeDocIds: streamResult.scopeDocIds || undefined,
        anchorTypes: streamResult.anchorTypes || undefined,
        attachmentsTypes: streamResult.attachmentsTypes || undefined,
        trustCheck: streamResult.trustCheck || undefined,
      })}\n\n`
    );

    res.end();
  } catch (error: any) {
    console.error('[Chat] Streaming error:', error);
    res.write(`data: ${JSON.stringify({ type: 'error', requestId, error: error.message })}\n\n`);
    res.end();
  }
};

// ============================================================================
// Export
// ============================================================================

export default {
  createConversation,
  getConversations,
  getConversation,
  deleteConversation,
  deleteAllConversations,
  sendMessage,
  sendMessageStream,
  getMessages,
  regenerateTitles,
};
