import { Router, Request, Response } from 'express';
import prisma from '../config/database';
import { getContainer } from '../bootstrap/container';
import { LanguageCode } from '../types/intentV3.types';
// import { runManualCleanup } from '../jobs/orphanCleanup.scheduler'; // Archived

const router = Router();

// DEV ONLY: Get verification code for testing
router.get('/get-verification-code/:email', async (req, res): Promise<any> => {
  try {
    const { email } = req.params;

    const pendingUser = await prisma.pendingUser.findUnique({
      where: { email: email.toLowerCase() },
      select: {
        email: true,
        emailCode: true,
        expiresAt: true,
        emailVerified: true,
      }
    });

    if (!pendingUser) {
      return res.status(404).json({ error: 'No pending user found' });
    }

    res.json({
      email: pendingUser.email,
      code: pendingUser.emailCode,
      expiresAt: pendingUser.expiresAt,
      verified: pendingUser.emailVerified
    });
  } catch (error) {
    console.error('Error getting verification code:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// DEV/ADMIN: Run manual orphan cleanup - ARCHIVED
// Service moved to artifacts/legacy/jobs/
router.post('/run-orphan-cleanup', async (req, res) => {
  res.status(501).json({
    success: false,
    error: 'Orphan cleanup service archived - not available',
  });
});

// ============================================================================
// Intent Classification Debug Endpoint
// ============================================================================

/**
 * GET/POST /api/dev/classify
 * Classify intent for debugging
 *
 * GET: /api/dev/classify?text=Hello&language=en
 * POST: { query: "Hello", language: "en" }
 */
router.all('/classify', async (req: Request, res: Response): Promise<any> => {
  try {
    const userId = req.user?.id;
    const text = (req.query.text as string) || req.body.query || req.body.text;
    const language = ((req.query.language as string) || req.body.language || 'en') as LanguageCode;

    if (!text) {
      return res.status(400).json({
        error: 'Text is required',
        usage: 'GET /api/dev/classify?text=your+query&language=en',
      });
    }

    const startTime = Date.now();
    const intentEngine = getContainer().getIntentEngine();

    const intent = await intentEngine.predict({
      text,
      language,
      context: { userId: userId || 'anonymous' },
    });

    const { domainEnforcementService } = await import('../services/core/domainEnforcement.service');
    const domainContext = domainEnforcementService.getDomainContext(intent.primaryIntent);

    res.status(200).json({
      intent: intent.primaryIntent,
      confidence: Math.round(intent.confidence * 100) / 100,
      language: intent.language,
      domain: domainContext.isDomainSpecific ? domainContext.domain : null,
      domainFileTypes: domainContext.fileTypeFilters || null,
      matchedPattern: intent.matchedPattern || null,
      matchedKeywords: intent.matchedKeywords || [],
      secondaryIntents: intent.secondaryIntents?.map(s => ({
        intent: s.name,
        confidence: Math.round(s.confidence * 100) / 100,
      })) || [],
      processingTimeMs: Date.now() - startTime,
      isAmbiguous: intent.metadata?.isAmbiguous || false,
      _query: text,
      _timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('[DEV] Classify error:', error);
    res.status(500).json({
      error: error.message,
      stack: error.stack,
    });
  }
});

/**
 * GET /api/dev/context
 * Get RAG context for debugging
 */
router.get('/context', async (req: Request, res: Response): Promise<any> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const { query, language = 'en' } = req.query;
    if (!query || typeof query !== 'string') {
      return res.status(400).json({ error: 'Query parameter is required' });
    }

    const intentEngine = getContainer().getIntentEngine();
    const intent = await intentEngine.predict({
      text: query,
      language: (language as LanguageCode) || 'en',
      context: { userId },
    });

    res.status(200).json({
      intent,
      primaryIntent: intent.primaryIntent,
      language: intent.language,
      confidence: intent.confidence,
    });
  } catch (error: any) {
    console.error('[DEV] Context error:', error);
    res.status(500).json({ error: error.message });
  }
});

export default router;
