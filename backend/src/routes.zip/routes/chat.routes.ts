/**
 * Chat Routes V1
 *
 * Single AI surface - all chat interactions go through the orchestrator.
 * No body mutation, no delegation to other controllers.
 */

import { Router } from 'express';
import * as chatController from '../controllers/chat.controller';
import { authenticateToken } from '../middleware/auth.middleware';
import { aiLimiter } from '../middleware/rateLimit.middleware';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Conversation routes
router.post('/conversations', chatController.createConversation);
router.get('/conversations', chatController.getConversations);
router.get('/conversations/:conversationId', chatController.getConversation);
router.delete('/conversations/:conversationId', chatController.deleteConversation);
router.delete('/conversations', chatController.deleteAllConversations);

// Message routes
router.post('/conversations/:conversationId/messages', aiLimiter, chatController.sendMessage);
router.get('/conversations/:conversationId/messages', chatController.getMessages);

// Streaming route - Single AI surface
// Frontend calls this directly, no body mutation, orchestrator handles everything
router.post('/conversations/:conversationId/messages/stream', aiLimiter, chatController.sendMessageStream);

// Legacy streaming path (for backward compatibility during migration)
router.post('/conversations/:conversationId/messages/adaptive/stream', aiLimiter, chatController.sendMessageStream);

// Utility routes (optional - can be removed for minimal surface)
// router.post('/regenerate-titles', chatController.regenerateTitles); // Archived - non-core

export default router;
