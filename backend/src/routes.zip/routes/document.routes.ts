/**
 * Document Routes - Slimmed for ChatGPT-feel certification
 *
 * Core endpoints only. Advanced features archived.
 */

import { Router } from 'express';
import * as documentController from '../controllers/document.controller';
import { authenticateToken } from '../middleware/auth.middleware';
import { uploadWithThumbnail, checkStorageCapacityAfterUpload } from '../middleware/upload.middleware';
import { uploadLimiter, downloadLimiter } from '../middleware/rateLimit.middleware';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// ============================================================================
// Core Upload Flow (signed URL workflow)
// ============================================================================
router.post('/upload-url', documentController.getUploadUrl);
router.post('/:id/confirm-upload', documentController.confirmUpload);

// Legacy direct upload (keep for backward compatibility)
router.post('/upload', uploadLimiter, uploadWithThumbnail, checkStorageCapacityAfterUpload, documentController.uploadDocument);

// ============================================================================
// Core Document Operations
// ============================================================================
router.get('/', documentController.listDocuments);
router.get('/:id/download', downloadLimiter, documentController.getDownloadUrl);
router.get('/:id/view-url', downloadLimiter, documentController.getViewUrl);
router.get('/:id/preview', downloadLimiter, documentController.getPreview);
router.get('/:id/status', documentController.getDocumentStatus);
router.get('/:id/progress', documentController.getDocumentProgress);
router.get('/:id/thumbnail', documentController.getThumbnail);
router.patch('/:id', documentController.updateDocument);
router.delete('/:id', documentController.deleteDocument);

// ============================================================================
// Archived Routes - Non-core for certification
// ============================================================================
// router.post('/upload-multiple', uploadLimiter, uploadMultiple, checkStorageCapacityAfterUpload, documentController.uploadMultipleDocuments);
// router.post('/reindex-all', documentController.reindexAllDocuments);
// router.delete('/delete-all', documentController.deleteAllDocuments);
// router.get('/test-libreoffice', documentController.testLibreOffice);
// router.get('/:id/stream', downloadLimiter, documentController.streamDocument);
// router.get('/:id/preview-pdf', downloadLimiter, documentController.streamPreviewPdf);
// router.post('/:id/retry-preview', documentController.retryPreviewPdf);
// router.get('/:id/slides', documentController.getPPTXSlides);
// router.post('/:id/regenerate-slides', documentController.regeneratePPTXSlides);
// router.patch('/:id/encryption', documentController.updateEncryptionMetadata);
// router.patch('/:id/markdown', documentController.updateMarkdown);
// router.post('/:id/export', documentController.exportDocument);
// router.post('/:id/share', documentController.shareDocument);
// router.post('/:id/search', documentController.searchInDocument);
// router.post('/:id/reprocess', documentController.reprocessDocument);
// router.post('/:id/retry', documentController.retryDocument);
// router.post('/:id/version', uploadLimiter, uploadSingle, documentController.uploadVersion);
// router.get('/:id/versions', documentController.getVersions);

export default router;
