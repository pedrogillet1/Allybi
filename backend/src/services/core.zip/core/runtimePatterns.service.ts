/**
 * RuntimePatterns Service
 *
 * Central service for loading and matching patterns from compiled bank data.
 * This replaces hardcoded patterns scattered across orchestrator, fileSearch, etc.
 *
 * Key APIs:
 * - isFileActionQuery(query, lang): Check if query is file navigation/listing
 * - isLocationQuery(query, lang): Check if query is "where is X" type
 * - isFollowupQuery(query, lang): Check if query references previous context
 * - getOperatorMatches(query, lang): Get scored operator matches
 * - getIntentMatches(query, lang): Get scored intent matches
 * - getFormatConstraints(intent, operator): Get allowed output shapes
 */

import * as fs from 'fs';
import * as path from 'path';
import { loadPatternBank, MasterPatternBank as PatternBank } from '../data/dataBankLoader.service';

// Types
export interface PatternMatch {
  id: string;
  pattern: string;
  confidence: number;
  operator?: string;
  subIntent?: string;
}

export interface OperatorMatch {
  operator: string;
  confidence: number;
  matchedPatterns: string[];
}

export interface IntentMatch {
  intent: string;
  confidence: number;
  matchedPatterns: string[];
  subIntent?: string;
}

export interface FormatConstraint {
  allowedShapes: string[];
  expectedTemplateIdPrefixes: string[];
}

interface RuntimeData {
  version: string;
  languages: string[];
  defaults: { language: string; intent: string; operator: string };
  operators: Record<string, {
    priority: number;
    patterns: Record<string, string[]>;
    negatives: Record<string, string[]>;
    allowedOutputShapes: string[];
    minConfidence: number;
  }>;
  intents: Record<string, {
    priority: number;
    description: string;
    operatorsAllowed: string[];
    patterns: Record<string, string[]>;
    negatives: Record<string, string[]>;
  }>;
  overlays: {
    followup: Record<string, string[]>;
    continue: Record<string, string[]>;
    clarifyRequired: Record<string, string[]>;
    driftDetectors: Record<string, string[]>;
  };
  scope: {
    typeRules: {
      anchorNouns: Record<string, Record<string, string[]>>;
    };
    confidencePolicy: Record<string, { autoScopeThreshold: number }>;
    disambiguation: { maxCandidates: number };
  };
  templates: {
    operatorTemplateMap: Record<string, FormatConstraint>;
  };
  policies: {
    bannedOpeners: string[];
    bannedPhrases: string[];
    completionGate: {
      forbidEllipsis: boolean;
      forbidDanglingMarkers: boolean;
      requireValidTableWhenRequested: boolean;
    };
  };
}

interface BankTrigger {
  id: string;
  pattern: string;
  confidence: number;
  operator?: string;
}

interface TriggerBank {
  bank_id: string;
  language: string;
  triggers?: BankTrigger[];
  subintents?: Record<string, { triggers: string[] }>;
}

class RuntimePatternsService {
  private static instance: RuntimePatternsService;
  private runtimeData: RuntimeData | null = null;
  private bankCache: Map<string, TriggerBank> = new Map();
  private compiledPatterns: Map<string, RegExp[]> = new Map();
  private patternBank: PatternBank | null = null; // Master pattern bank for language detection

  private readonly DATA_DIR = path.join(__dirname, '../../data');
  private readonly BANKS_DIR = path.join(__dirname, '../../../data_banks');

  private constructor() {
    this.loadRuntimeData();
    this.loadPatternBank();
    // DEPRECATED: loadBanks() and loadRoutingPatterns() are no longer needed
    // All routing should use the compiled runtime JSON (intent_patterns.runtime.json)
    // Only load preamble patterns for formatting (until moved to AnswerComposer)
    this.loadBanks();
  }

  private loadPatternBank(): void {
    try {
      this.patternBank = loadPatternBank();
    } catch (err) {
      console.warn('[RuntimePatterns] Failed to load pattern bank for language detection');
      this.patternBank = null;
    }
  }

  static getInstance(): RuntimePatternsService {
    if (!RuntimePatternsService.instance) {
      RuntimePatternsService.instance = new RuntimePatternsService();
    }
    return RuntimePatternsService.instance;
  }

  // ==================== Loading ====================

  private loadRuntimeData(): void {
    try {
      const runtimePath = path.join(this.DATA_DIR, 'intent_patterns.runtime.json');
      if (fs.existsSync(runtimePath)) {
        const content = fs.readFileSync(runtimePath, 'utf-8');
        this.runtimeData = JSON.parse(content);
        console.log(`[RuntimePatterns] Loaded runtime data v${this.runtimeData?.version}`);
      } else {
        console.warn('[RuntimePatterns] Runtime JSON not found, using defaults');
        this.runtimeData = this.getDefaultRuntimeData();
      }
    } catch (error) {
      console.error('[RuntimePatterns] Error loading runtime data:', error);
      this.runtimeData = this.getDefaultRuntimeData();
    }
  }

  /**
   * Load pattern banks from data_banks directory.
   * Loads both routing patterns and formatting patterns.
   */
  private loadBanks(): void {
    // Bank files to load - includes routing patterns for isInventoryQuery, etc.
    const bankFiles = [
      'formatting/preamble_patterns.en.json',
      'formatting/preamble_patterns.pt.json',
      'routing/routing_patterns.en.json',
      'routing/routing_patterns.pt.json',
    ];

    for (const file of bankFiles) {
      const fullPath = path.join(this.BANKS_DIR, file);
      if (fs.existsSync(fullPath)) {
        try {
          const content = fs.readFileSync(fullPath, 'utf-8');
          const bank = JSON.parse(content) as TriggerBank;
          const key = file
            .replace('.json', '')
            .replace('triggers/', '')
            .replace('overlays/', '')
            .replace('routing/', '')
            .replace('formatting/', '');
          this.bankCache.set(key, bank);
          console.log(`[RuntimePatterns] Loaded bank: ${key}`);
        } catch (error) {
          console.warn(`[RuntimePatterns] Error loading bank ${file}:`, error);
        }
      }
    }
  }

  /**
   * @deprecated Routing patterns should be in compiled runtime JSON.
   * Use operators/intents from runtimeData instead.
   */
  private loadRoutingPatterns(): void {
    console.warn('[DEPRECATED] loadRoutingPatterns - use compiled runtime JSON operators/intents');
    // Kept empty - routingPatterns object should not be used
  }

  // ==================== Pattern Array Access (for method-specific patterns) ====================

  /**
   * Get patterns array by category key
   * BANK-DRIVEN ONLY - uses runtime JSON operators and overlays
   * If patterns are missing, add them to the compiled runtime JSON
   * @deprecated Use getOperatorMatches() or getIntentMatches() for routing
   */
  getPatternArray(key: string, lang: string = 'en'): string[] {
    const normalizedLang = this.normalizeLang(lang);

    // Check operators first
    if (this.runtimeData?.operators?.[key]?.patterns?.[normalizedLang]) {
      return this.runtimeData.operators[key].patterns[normalizedLang];
    }

    // Check overlays (followup, continue, clarifyRequired, driftDetectors)
    for (const overlayType of ['followup', 'continue', 'clarifyRequired', 'driftDetectors']) {
      if (key === overlayType && this.runtimeData?.overlays?.[overlayType as keyof typeof this.runtimeData.overlays]?.[normalizedLang]) {
        return this.runtimeData.overlays[overlayType as keyof typeof this.runtimeData.overlays][normalizedLang];
      }
    }

    // Check intents
    if (this.runtimeData?.intents?.[key]?.patterns?.[normalizedLang]) {
      return this.runtimeData.intents[key].patterns[normalizedLang];
    }

    // Log warning in development to catch missing patterns
    if (process.env.NODE_ENV !== 'production') {
      console.warn(`[RuntimePatterns] Missing pattern category: ${key} - add to compiled runtime JSON`);
    }
    return [];
  }

  private getDefaultRuntimeData(): RuntimeData {
    return {
      version: 'default',
      languages: ['en', 'pt'],
      defaults: { language: 'en', intent: 'documents', operator: 'summarize' },
      operators: {},
      intents: {},
      overlays: { followup: {}, continue: {}, clarifyRequired: {}, driftDetectors: {} },
      scope: { typeRules: { anchorNouns: {} }, confidencePolicy: {}, disambiguation: { maxCandidates: 5 } },
      templates: { operatorTemplateMap: {} },
      policies: { bannedOpeners: [], bannedPhrases: [], completionGate: { forbidEllipsis: true, forbidDanglingMarkers: true, requireValidTableWhenRequested: true } }
    };
  }

  // ==================== Pattern Compilation ====================

  private compilePatterns(key: string, patterns: string[]): RegExp[] {
    if (this.compiledPatterns.has(key)) {
      return this.compiledPatterns.get(key)!;
    }

    const compiled: RegExp[] = [];
    for (const pattern of patterns) {
      try {
        // If pattern looks like regex (contains special chars), compile as-is
        if (/[()|\[\]\\^$.*+?{}]/.test(pattern)) {
          compiled.push(new RegExp(pattern, 'i'));
        } else {
          // Plain text: escape special chars and match as substring
          const escaped = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          compiled.push(new RegExp(`\\b${escaped}\\b`, 'i'));
        }
      } catch (error) {
        // Skip invalid regex patterns
        console.warn(`[RuntimePatterns] Invalid pattern: ${pattern}`);
      }
    }

    this.compiledPatterns.set(key, compiled);
    return compiled;
  }

  private matchPatterns(query: string, patterns: RegExp[]): boolean {
    const normalized = query.toLowerCase().trim();
    return patterns.some(p => p.test(normalized));
  }

  private countMatches(query: string, patterns: RegExp[]): number {
    const normalized = query.toLowerCase().trim();
    return patterns.filter(p => p.test(normalized)).length;
  }

  // ==================== File Actions Detection ====================

  /**
   * Check if query is a file action (list, filter, locate, open)
   */
  isFileActionQuery(query: string, lang: string = 'en'): boolean {
    const normalizedLang = this.normalizeLang(lang);

    // Get patterns from runtime data
    const runtimePatterns = this.runtimeData?.intents?.file_actions?.patterns?.[normalizedLang] || [];
    if (runtimePatterns.length > 0) {
      const compiled = this.compilePatterns(`file_actions_${normalizedLang}`, runtimePatterns);
      if (this.matchPatterns(query, compiled)) {
        return true;
      }
    }

    // Check bank file for richer patterns
    const bankKey = `file_actions_subintents.${normalizedLang}`;
    const bank = this.bankCache.get(bankKey);
    if (bank?.subintents) {
      for (const subIntent of Object.values(bank.subintents)) {
        if (subIntent.triggers?.some(t => query.toLowerCase().includes(t.toLowerCase()))) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Check if query is a location query ("where is X", "onde está X")
   * BANK-DRIVEN ONLY - uses runtime JSON operators.locate patterns
   */
  isLocationQuery(query: string, lang: string = 'en'): boolean {
    const normalizedLang = this.normalizeLang(lang);

    // Use ONLY runtime JSON operators.locate patterns
    const locatePatterns = this.runtimeData?.operators?.locate?.patterns?.[normalizedLang] || [];
    if (locatePatterns.length > 0) {
      const compiled = this.compilePatterns(`locate_${normalizedLang}`, locatePatterns);
      if (this.matchPatterns(query, compiled)) {
        return true;
      }
    }

    // NO FALLBACK - if patterns don't match, return false
    // This ensures routing is purely bank-driven
    return false;
  }

  /**
   * Check if query is a followup referencing previous context
   * BANK-DRIVEN ONLY - uses runtime JSON overlays.followup patterns
   */
  isFollowupQuery(query: string, lang: string = 'en'): boolean {
    const normalizedLang = this.normalizeLang(lang);

    // Use ONLY runtime JSON overlays.followup patterns
    const followupPatterns = this.runtimeData?.overlays?.followup?.[normalizedLang] || [];
    if (followupPatterns.length > 0) {
      const compiled = this.compilePatterns(`followup_${normalizedLang}`, followupPatterns);
      if (this.matchPatterns(query, compiled)) {
        return true;
      }
    }

    // NO FALLBACK - if patterns don't match, return false
    // This ensures routing is purely bank-driven
    return false;
  }

  // ==================== Intent/Operator Detection ====================

  /**
   * Get intent matches with confidence scores
   */
  getIntentMatches(query: string, lang: string = 'en'): IntentMatch[] {
    const normalizedLang = this.normalizeLang(lang);
    const matches: IntentMatch[] = [];

    // Check each intent's patterns
    for (const [intentName, intent] of Object.entries(this.runtimeData?.intents || {})) {
      const patterns = intent.patterns?.[normalizedLang] || [];
      const negatives = intent.negatives?.[normalizedLang] || [];

      const compiledPatterns = this.compilePatterns(`intent_${intentName}_${normalizedLang}`, patterns);
      const compiledNegatives = this.compilePatterns(`intent_${intentName}_neg_${normalizedLang}`, negatives);

      const matchCount = this.countMatches(query, compiledPatterns);
      const negCount = this.countMatches(query, compiledNegatives);

      if (matchCount > 0 && negCount === 0) {
        const confidence = Math.min(0.95, 0.5 + (matchCount * 0.15));
        matches.push({
          intent: intentName,
          confidence,
          matchedPatterns: patterns.filter((_, i) => compiledPatterns[i]?.test(query))
        });
      }
    }

    // Sort by confidence descending
    return matches.sort((a, b) => b.confidence - a.confidence);
  }

  /**
   * Get operator matches with confidence scores
   */
  getOperatorMatches(query: string, lang: string = 'en'): OperatorMatch[] {
    const normalizedLang = this.normalizeLang(lang);
    const matches: OperatorMatch[] = [];

    // Check each operator's patterns
    for (const [opName, op] of Object.entries(this.runtimeData?.operators || {})) {
      const patterns = op.patterns?.[normalizedLang] || [];
      const negatives = op.negatives?.[normalizedLang] || [];

      const compiledPatterns = this.compilePatterns(`op_${opName}_${normalizedLang}`, patterns);
      const compiledNegatives = this.compilePatterns(`op_${opName}_neg_${normalizedLang}`, negatives);

      const matchCount = this.countMatches(query, compiledPatterns);
      const negCount = this.countMatches(query, compiledNegatives);

      if (matchCount > 0 && negCount === 0) {
        const confidence = Math.min(0.95, op.minConfidence + (matchCount * 0.1));
        matches.push({
          operator: opName,
          confidence,
          matchedPatterns: patterns.filter((_, i) => compiledPatterns[i]?.test(query))
        });
      }
    }

    return matches.sort((a, b) => b.confidence - a.confidence);
  }

  // ==================== Format/Template Access ====================

  /**
   * Get format constraints for an operator
   */
  getFormatConstraints(operator: string): FormatConstraint | null {
    return this.runtimeData?.templates?.operatorTemplateMap?.[operator] || null;
  }

  /**
   * Get allowed output shapes for an operator
   */
  getAllowedShapes(operator: string): string[] {
    return this.runtimeData?.operators?.[operator]?.allowedOutputShapes || [];
  }

  /**
   * Get policy rules
   */
  getPolicies() {
    return this.runtimeData?.policies || {
      bannedOpeners: [],
      bannedPhrases: [],
      completionGate: { forbidEllipsis: true, forbidDanglingMarkers: true, requireValidTableWhenRequested: true }
    };
  }

  // ==================== Bank-Driven Routing (replaces hardcoded patterns) ====================

  /**
   * Match a category from the routing_patterns bank
   */
  private matchRoutingCategory(query: string, category: string, lang: string = 'en'): boolean {
    const normalizedLang = this.normalizeLang(lang);
    const bankKey = `routing_patterns.${normalizedLang}`;
    const bank = this.bankCache.get(bankKey);

    if (!bank) return false;

    // Bank structure: { _meta, inventory: { patterns: [...] }, ... }
    const categoryData = (bank as any)[category];
    if (!categoryData?.patterns) return false;

    const cacheKey = `routing_${category}_${normalizedLang}`;
    const compiled = this.compilePatterns(cacheKey, categoryData.patterns);
    return this.matchPatterns(query, compiled);
  }

  /**
   * Check if query is an inventory/file listing query
   * BANK-DRIVEN ONLY - uses routing_patterns bank
   */
  isInventoryQuery(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'inventory', lang);
  }

  /**
   * Check if query is a doc_stats query (page count, slide count, sheet count)
   * BANK-DRIVEN ONLY - uses doc_stats_* patterns from routing_patterns bank
   */
  isDocStatsQuery(query: string, lang: string = 'en'): { isDocStats: boolean; statsType?: 'pages' | 'slides' | 'sheets' | 'words' | 'size' } {
    // Check specific doc_stats patterns from bank (most specific first)
    if (this.matchRoutingCategory(query, 'doc_stats_page_count', lang)) {
      return { isDocStats: true, statsType: 'pages' };
    }
    if (this.matchRoutingCategory(query, 'doc_stats_slide_count', lang)) {
      return { isDocStats: true, statsType: 'slides' };
    }
    if (this.matchRoutingCategory(query, 'doc_stats_sheet_count', lang)) {
      return { isDocStats: true, statsType: 'sheets' };
    }

    // Fallback: check generic count + page/slide/sheet patterns
    const hasCountPattern = this.matchRoutingCategory(query, 'count_list_type_query', lang);
    const hasPageSlideSheet = this.matchRoutingCategory(query, 'page_slide_sheet_query', lang);

    if (hasCountPattern && hasPageSlideSheet) {
      // Use getDocStatsType to determine which type (bank-loaded patterns)
      const stats = this.getDocStatsType(query);
      if (stats.isPageQuery) return { isDocStats: true, statsType: 'pages' };
      if (stats.isSlideQuery) return { isDocStats: true, statsType: 'slides' };
      if (stats.isSheetQuery) return { isDocStats: true, statsType: 'sheets' };
      if (stats.isWordQuery) return { isDocStats: true, statsType: 'words' };
      if (stats.isSizeQuery) return { isDocStats: true, statsType: 'size' };
      return { isDocStats: true, statsType: 'pages' };
    }

    return { isDocStats: false };
  }

  /**
   * Check if query is an open file request
   */
  isOpenFileRequest(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'open_file', lang);
  }

  /**
   * Check if query is a content query (summarize, explain, etc.)
   */
  isContentQuery(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'content_query', lang);
  }

  /**
   * Check if query contains document reference patterns
   */
  hasDocumentReference(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'doc_reference', lang);
  }

  /**
   * Check if query is PDF-specific content query
   */
  isPdfContentQuery(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'pdf_content', lang);
  }

  /**
   * Check if query is slide/presentation content query
   */
  isSlideContentQuery(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'slide_content', lang);
  }

  /**
   * Check if query contains reasoning context patterns
   */
  isReasoningContextQuery(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'reasoning_context', lang);
  }

  /**
   * Check if query contains pronoun references (it, this, that)
   */
  hasPronounReference(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'pronoun_reference', lang);
  }

  /**
   * Check if query indicates scope continuation
   */
  isScopeContinuation(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'scope_continuation', lang);
  }

  /**
   * Check if query is a workspace summary request
   */
  isWorkspaceSummaryQuery(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'workspace_summary', lang);
  }

  /**
   * Check if response is lazy (to block)
   */
  isLazyResponse(text: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(text, 'lazy_response_blockers', lang);
  }

  /**
   * Check if query has format request
   */
  hasFormatRequest(query: string, lang: string = 'en'): boolean {
    return this.matchRoutingCategory(query, 'format_request', lang);
  }

  /**
   * Check if query contains an explicit filename with extension
   * @deprecated Move to FileActionParsingService - use regex detection
   */
  hasExplicitFilename(query: string, _lang: string = 'en'): boolean {
    // Bank-driven: detect common file extensions
    return /\b[\w-]+\.(pdf|docx?|xlsx?|pptx?|txt|csv|json|xml|md|html?)\b/i.test(query);
  }

  /**
   * Check if query is a simple open command (e.g., "open it", "show that")
   * @deprecated Move to FileActionParsingService
   */
  isSimpleOpen(query: string, _lang: string = 'en'): boolean {
    return /\b(open|show|abrir|mostrar)\s+(it|that|this|esse|isso|este|esta)\b/i.test(query);
  }

  /**
   * Check if query is a followup expansion pattern (what about X, how about Y)
   * @deprecated Use overlays.followup from runtime JSON
   */
  isFollowupExpansion(query: string, lang: string = 'en'): boolean {
    return this.isFollowupQuery(query, lang) ||
      /\b(what|how)\s+about\b/i.test(query) ||
      /\be\s+(quanto\s+a|sobre)\b/i.test(query);
  }

  // ==================== Preamble Stripping ====================

  /**
   * Strip preamble phrases from the beginning of an answer
   */
  stripPreamble(answer: string, lang: string = 'en'): string {
    const normalizedLang = this.normalizeLang(lang);
    const bankKey = `preamble_patterns.${normalizedLang}`;
    const bank = this.bankCache.get(bankKey);

    if (!bank) return answer;

    let result = answer;

    // Process each preamble category
    for (const [key, value] of Object.entries(bank)) {
      if (key === '_meta' || key === 'bank_id' || key === 'language') continue;

      const categoryData = value as { patterns?: string[] };
      if (!categoryData?.patterns) continue;

      const cacheKey = `preamble_${key}_${normalizedLang}`;
      const compiled = this.compilePatterns(cacheKey, categoryData.patterns);

      for (const regex of compiled) {
        result = result.replace(regex, '').trim();
      }
    }

    return result;
  }

  // ==================== Scope Detection ====================

  /**
   * Detect file type from query using anchor nouns
   */
  detectFileType(query: string, lang: string = 'en'): string | null {
    const normalizedLang = this.normalizeLang(lang);
    const anchorNouns = this.runtimeData?.scope?.typeRules?.anchorNouns || {};

    for (const [fileType, nouns] of Object.entries(anchorNouns)) {
      const langNouns = (nouns as Record<string, string[]>)[normalizedLang] || [];
      for (const noun of langNouns) {
        if (query.toLowerCase().includes(noun.toLowerCase())) {
          return fileType;
        }
      }
    }

    return null;
  }

  /**
   * Get confidence threshold for auto-scoping
   */
  getAutoScopeThreshold(intent: string): number {
    return this.runtimeData?.scope?.confidencePolicy?.[intent]?.autoScopeThreshold || 0.6;
  }

  // ==================== Utilities ====================

  private normalizeLang(lang: string): string {
    const lower = lang.toLowerCase();
    if (lower.startsWith('pt')) return 'pt';
    if (lower.startsWith('es')) return 'es';
    return 'en';
  }

  /**
   * Get supported languages
   */
  getSupportedLanguages(): string[] {
    return this.runtimeData?.languages || ['en', 'pt'];
  }

  /**
   * Get default values
   */
  getDefaults() {
    return this.runtimeData?.defaults || { language: 'en', intent: 'documents', operator: 'summarize' };
  }

  /**
   * Reload runtime data (for hot reloading)
   */
  reload(): void {
    this.compiledPatterns.clear();
    this.bankCache.clear();
    this.loadRuntimeData();
    this.loadBanks();
    console.log('[RuntimePatterns] Reloaded all data');
  }

  /**
   * Debug: get loaded bank keys
   */
  getLoadedBanks(): string[] {
    return Array.from(this.bankCache.keys());
  }

  // ==================== DEPRECATED: Answer Cleanup Methods ====================
  // These methods should be moved to AnswerComposer pipeline, not in routing service.

  /** @deprecated Move to AnswerComposer pipeline */
  stripStepMarkers(text: string): string {
    console.warn('[DEPRECATED] stripStepMarkers - move to AnswerComposer');
    return text;
  }

  /** @deprecated Move to AnswerComposer pipeline */
  cleanupEllipsis(text: string): string {
    console.warn('[DEPRECATED] cleanupEllipsis - move to AnswerComposer');
    return text;
  }

  /** @deprecated Move to AnswerComposer pipeline */
  cleanupTrailingBullets(text: string): string {
    console.warn('[DEPRECATED] cleanupTrailingBullets - move to AnswerComposer');
    return text;
  }

  /** @deprecated Move to AnswerComposer pipeline */
  normalizeNewlines(text: string): string {
    console.warn('[DEPRECATED] normalizeNewlines - move to AnswerComposer');
    return text;
  }

  /** @deprecated Move to AnswerComposer pipeline */
  cleanupAnswer(text: string): string {
    console.warn('[DEPRECATED] cleanupAnswer - move to AnswerComposer');
    return text;
  }

  /**
   * Check if text starts with valid answer pattern
   */
  startsWithValidAnswer(text: string): boolean {
    const stripped = text.replace(/^\s+/, '');
    return /^[-•*\d]|^[A-Z]|^\*{1,2}[A-Za-z]/.test(stripped);
  }

  /**
   * Extract UUID from chunk ID
   */
  extractUuidFromChunkId(chunkId: string): string | null {
    const match = chunkId.match(/^([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})-\d+$/i);
    return match ? match[1] : null;
  }

  // ==================== DEPRECATED: Phase 5c Query Helpers ====================
  // These should be moved to FileActionParsingService

  /** @deprecated Move to FileActionParsingService */
  isListAllQuery(_text: string): boolean {
    console.warn('[DEPRECATED] isListAllQuery - move to FileActionParsingService');
    return false;
  }

  /** @deprecated Move to ConversationMemoryService */
  isMemoryQuery(_text: string): { isMemory: boolean; content?: string } {
    console.warn('[DEPRECATED] isMemoryQuery - move to ConversationMemoryService');
    return { isMemory: false };
  }

  /** @deprecated Move to FileActionParsingService */
  isShowDateQuery(_text: string): boolean {
    console.warn('[DEPRECATED] isShowDateQuery - move to FileActionParsingService');
    return false;
  }

  /** @deprecated Move to FileActionParsingService */
  isGoBackFolder(_text: string): boolean {
    console.warn('[DEPRECATED] isGoBackFolder - move to FileActionParsingService');
    return false;
  }

  /** @deprecated Use overlays.followup from runtime JSON instead */
  isWhatHowAboutFollowup(_text: string): boolean {
    console.warn('[DEPRECATED] isWhatHowAboutFollowup - use runtime JSON overlays');
    return false;
  }

  /** @deprecated Move to FileActionParsingService */
  stripQuotes(text: string): string {
    return text.replace(/^['"`]+|['"`]+$/g, '');
  }

  /** @deprecated Move to FileActionParsingService */
  stripFilePrefix(text: string): string {
    return text.replace(/^(the\s+)?(file|document)\s+/i, '');
  }

  /** @deprecated Move to FileActionParsingService */
  isMostImportantFileQuery(_text: string): { isMatch: boolean; topic?: string } {
    console.warn('[DEPRECATED] isMostImportantFileQuery - move to FileActionParsingService');
    return { isMatch: false };
  }

  /** @deprecated Move to FileActionParsingService */
  getFileNameFromOpenQuery(_text: string): string | null {
    console.warn('[DEPRECATED] getFileNameFromOpenQuery - move to FileActionParsingService');
    return null;
  }

  /** @deprecated Move to FileActionParsingService */
  getFileNameFromLocateQuery(_text: string): string | null {
    console.warn('[DEPRECATED] getFileNameFromLocateQuery - move to FileActionParsingService');
    return null;
  }

  /** @deprecated Move to FileActionParsingService */
  isPronounReferenceSimple(_text: string): boolean {
    console.warn('[DEPRECATED] isPronounReferenceSimple - move to FileActionParsingService');
    return false;
  }

  /**
   * Detect language from query using BANK-DRIVEN weighted indicators
   * Loaded from pattern_bank_master.json languageIndicators section
   * Weights: strong=5, medium=3, weak=1
   */
  detectLanguageFromQuery(query: string): 'en' | 'pt' | 'es' {
    // If pattern bank not loaded, fall back to basic detection
    if (!this.patternBank?.languageIndicators) {
      // Minimal fallback (should rarely hit this)
      if (/\b(você|mostre|onde|qual)\b/i.test(query)) return 'pt';
      if (/\b(usted|cuántos|dónde)\b/i.test(query)) return 'es';
      return 'en';
    }

    const indicators = this.patternBank.languageIndicators;
    const q = query.toLowerCase();

    // Tokenize for word-boundary matching
    const tokens = q.replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter(t => t.length > 0);
    const stripped = q.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); // Remove diacritics for fallback

    // Calculate weighted scores for each language
    const calculateScore = (langIndicators: { strong: string[]; medium: string[]; weak: string[] }): number => {
      let score = 0;
      // Strong indicators (weight 5)
      for (const pattern of langIndicators.strong || []) {
        if (this.matchesIndicator(pattern, q, tokens, stripped)) score += 5;
      }
      // Medium indicators (weight 3)
      for (const pattern of langIndicators.medium || []) {
        if (this.matchesIndicator(pattern, q, tokens, stripped)) score += 3;
      }
      // Weak indicators (weight 1)
      for (const pattern of langIndicators.weak || []) {
        if (this.matchesIndicator(pattern, q, tokens, stripped)) score += 1;
      }
      return score;
    };

    const scores = {
      pt: calculateScore(indicators.pt),
      es: calculateScore(indicators.es),
      en: calculateScore(indicators.en),
    };

    // Return language with highest score (default to 'en' on ties)
    if (scores.pt > scores.en && scores.pt > scores.es) return 'pt';
    if (scores.es > scores.en && scores.es > scores.pt) return 'es';
    return 'en';
  }

  /**
   * Helper: Check if an indicator pattern matches the query
   * Supports both phrase matching and single-token matching
   */
  private matchesIndicator(pattern: string, query: string, tokens: string[], stripped: string): boolean {
    const p = pattern.toLowerCase();
    const pStripped = p.normalize('NFD').replace(/[\u0300-\u036f]/g, '');

    if (pattern.includes(' ')) {
      // Phrase: check substring with word boundaries
      const phraseRegex = new RegExp(`\\b${this.escapeRegexStr(p)}\\b`, 'i');
      return phraseRegex.test(query) || phraseRegex.test(stripped);
    } else {
      // Single token: exact match in token list
      return tokens.includes(p) || tokens.includes(pStripped);
    }
  }

  /**
   * Escape special regex characters in a string
   */
  private escapeRegexStr(str: string): string {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // ==================== DEPRECATED: Phase 5c Methods ====================
  // These methods are DEPRECATED and should NOT be used.
  // They belong in FileActionParsingService or ScopeGateService, not routing.
  // RuntimePatternsService should ONLY do: load patterns, compile, score matches.

  /** @deprecated Move to FileActionParsingService */
  isDisambiguationOlder(_text: string): boolean {
    console.warn('[DEPRECATED] isDisambiguationOlder - move to FileActionParsingService');
    return false;
  }

  /** @deprecated Move to FileActionParsingService */
  isDisambiguationNewer(_text: string): boolean {
    console.warn('[DEPRECATED] isDisambiguationNewer - move to FileActionParsingService');
    return false;
  }

  /** @deprecated Move to FileActionParsingService */
  isDisambiguationOther(_text: string): boolean {
    console.warn('[DEPRECATED] isDisambiguationOther - move to FileActionParsingService');
    return false;
  }

  /** @deprecated Move to FileActionParsingService */
  getDisambiguationByType(_text: string): { ext?: string[]; keywords?: string[] } | null {
    console.warn('[DEPRECATED] getDisambiguationByType - move to FileActionParsingService');
    return null;
  }

  // ==================== Phase 5c: Intent Detection Methods ====================
  // BANK-DRIVEN ONLY - no hardcoded regexes
  // Uses runtime JSON operators and intents for matching

  /**
   * Detect file action intent from query (returns operator type)
   * BANK-DRIVEN: Uses runtime JSON file_actions intent and operators
   */
  detectFileActionIntent(text: string): string | null {
    const lang = this.detectLanguageFromQuery(text);

    // Get operator matches from runtime JSON
    const matches = this.getOperatorMatches(text, lang);

    // File action operators (from runtime JSON operators section)
    // NOTE: These must match the operators defined in compile_runtime_patterns.ts
    const fileActionOperators = ['list', 'filter', 'open', 'locate_file', 'again', 'group', 'sort', 'count'];

    // Find the highest confidence file action operator
    for (const match of matches) {
      if (fileActionOperators.includes(match.operator)) {
        return match.operator;
      }
    }

    // Check file_actions intent patterns from runtime JSON
    const intentMatches = this.getIntentMatches(text, lang);
    const fileActionsMatch = intentMatches.find(m => m.intent === 'file_actions');
    if (fileActionsMatch && fileActionsMatch.confidence > 0.5) {
      // Determine sub-operator from operator matches
      const topOperator = matches[0];
      if (topOperator) {
        return topOperator.operator;
      }
    }

    // Check doc_stats intent
    const docStatsMatch = intentMatches.find(m => m.intent === 'doc_stats');
    if (docStatsMatch && docStatsMatch.confidence > 0.5) {
      return 'doc_stats';
    }

    // Check help intent
    const helpMatch = intentMatches.find(m => m.intent === 'help');
    if (helpMatch && helpMatch.confidence > 0.5) {
      return 'help';
    }

    return null;
  }

  /**
   * Detect document intent from query (returns operator type)
   * BANK-DRIVEN: Uses runtime JSON operators for matching
   */
  detectDocumentIntent(text: string): string | null {
    const lang = this.detectLanguageFromQuery(text);

    // Get operator matches from runtime JSON
    const matches = this.getOperatorMatches(text, lang);

    // Document operators (from runtime JSON operators section)
    // NOTE: Uses locate_content for content location (separate from file location)
    const documentOperators = ['summarize', 'compare', 'compute', 'extract', 'explain', 'locate_content'];

    // Find the highest confidence document operator
    for (const match of matches) {
      if (documentOperators.includes(match.operator)) {
        return match.operator;
      }
    }

    return null;
  }

  /**
   * Expand "what/how about X" to full query with topic replacement
   * @deprecated Move to FollowupService
   */
  expandWhatHowAbout(text: string, replacement: string): string {
    const patterns = [
      /^(what|how)\s+about\s+/i,
      /^e\s+(quanto\s+a|sobre)\s+/i,
      /^y\s+(qué\s+hay\s+de|sobre)\s+/i
    ];
    for (const regex of patterns) {
      const expanded = text.replace(regex, replacement);
      if (expanded !== text) return expanded;
    }
    return text;
  }

  /**
   * Check if query matches "what/how about" pattern
   * @deprecated Move to FollowupService
   */
  isWhatHowAbout(text: string): boolean {
    return /\b(what|how)\s+about\b/i.test(text) ||
      /\be\s+(quanto\s+a|sobre)\b/i.test(text) ||
      /\by\s+(qué\s+hay\s+de|sobre)\b/i.test(text);
  }

  /**
   * Extract filename from "open the [NAME] file" patterns
   * Returns filename if matched, null otherwise
   * @deprecated Move to FileActionParsingService
   */
  getOpenNameFileMatch(query: string): string | null {
    const patterns = this.getPatternArray('open');
    const skipWords = ['the', 'my', 'a', 'this', 'that', 'file', 'document', 'it'];

    for (const p of patterns) {
      try {
        const regex = new RegExp(p, 'i');
        const match = query.match(regex);
        if (match && match[2]) {
          const fileName = match[2].trim().replace(/[?.!]+$/, '');
          // Skip if it's a type word or too short
          if (fileName && fileName.length >= 3 && !skipWords.includes(fileName.toLowerCase())) {
            return fileName;
          }
        }
      } catch {
        // Skip invalid patterns
      }
    }
    return null;
  }

  /**
   * Extract filename from "where would I find X" patterns (with optional trailing clause)
   * Returns filename if matched, null otherwise
   * @deprecated Move to FileActionParsingService
   */
  getWhereWithClauseMatch(query: string): string | null {
    const patterns = [
      /\bwhere\s+(would|can|do)\s+I\s+find\s+(.+?)(?:\s+if|\?|$)/i,
      /\bonde\s+(posso|eu)\s+(encontrar|achar)\s+(.+?)(?:\s+se|\?|$)/i
    ];

    for (const regex of patterns) {
      const match = query.match(regex);
      if (match) {
        const fileName = (match[3] || match[2])?.trim()
          .replace(/[?.!]+$/, '')
          .replace(/\s+if\s+.*$/i, '');
        if (fileName && fileName.length >= 3 && !['it', 'that', 'this', 'the'].includes(fileName.toLowerCase())) {
          return fileName;
        }
      }
    }
    return null;
  }

  /**
   * Extract filename from search patterns (find/locate/search for)
   * Returns filename if matched, null otherwise
   * @deprecated Move to FileActionParsingService
   */
  getSearchPatternMatch(query: string): string | null {
    const patterns = [
      /\b(find|locate|search\s+for|look\s+for|buscar|encontrar|procurar)\s+(.+?)(?:\?|$)/i
    ];

    for (const regex of patterns) {
      const match = query.match(regex);
      if (match) {
        const candidate = match[2]?.trim().replace(/[?.!]+$/, '');
        if (candidate && candidate.length >= 2) {
          return candidate;
        }
      }
    }
    return null;
  }

  /**
   * Extract search term from "which file mentions X" patterns
   * Returns search term if matched, null otherwise
   * @deprecated Move to FileActionParsingService
   */
  getWhichFileMentionsMatch(query: string): string | null {
    const patterns = this.getPatternArray('locate_content');
    const noiseWords = ['the', 'all', 'my', 'is', 'are', 'in', 'across', 'files', 'documents', 'file', 'document', 'mentions', 'mention', 'of', 'about', 'on', 'regarding', 'covering'];

    for (const p of patterns) {
      try {
        const regex = new RegExp(p, 'i');
        const match = query.match(regex);
        if (match) {
          // Priority order: 2 first (typically the main capture), then 4, 3, 1
          for (const idx of [2, 4, 3, 1]) {
            const candidate = match[idx]?.trim()
              .replace(/[?.!]+$/, '')
              .replace(/\s+(across|in)\s+.+$/i, '');
            // Skip if it's a common noise word or too short
            if (candidate && candidate.length >= 2 && !noiseWords.includes(candidate.toLowerCase())) {
              return candidate;
            }
          }
        }
      } catch {
        // Skip invalid patterns
      }
    }
    return null;
  }

  /**
   * Strip quotes from string
   * @deprecated Move to FileActionParsingService
   */
  stripQuotesCleanup(text: string): string {
    return text.replace(/^['"`]+|['"`]+$/g, '');
  }

  /**
   * Strip "the file" / "document" prefix
   * @deprecated Move to FileActionParsingService
   */
  stripFilePrefixCleanup(text: string): string {
    return text.replace(/^(the\s+)?(file|document|arquivo|documento)\s+/i, '');
  }

  /**
   * Clean up extracted filename (quotes and file prefix)
   * @deprecated Move to FileActionParsingService
   */
  cleanupExtractedFileName(text: string): string {
    let result = this.stripQuotesCleanup(text);
    result = this.stripFilePrefixCleanup(result);
    return result.trim();
  }

  /**
   * Strip trailing location words (located, stored, saved, at, in)
   * @deprecated Move to FileActionParsingService
   */
  stripTrailingLocationWords(text: string): string {
    return text.replace(/\s+(located|stored|saved|at|in)\s*$/i, '');
  }

  /**
   * Strip trailing "folder" word
   * @deprecated Move to FileActionParsingService
   */
  stripTrailingFolderWord(text: string): string {
    return text.replace(/\s+(folder|directory|pasta)\s*$/i, '');
  }

  /**
   * Full filename extraction cleanup (quotes, prefix, location words, punctuation)
   * @deprecated Move to FileActionParsingService
   */
  cleanupExtractedFileNameFull(text: string): string {
    let result = this.stripQuotesCleanup(text);
    result = this.stripFilePrefixCleanup(result);
    result = this.stripTrailingLocationWords(result);
    result = result.replace(/[?.!]+$/, ''); // Remove trailing punctuation
    return result.trim();
  }

  // ==================== Additional Methods (called by orchestrator) ====================

  /**
   * Get followup sub-intent from context
   */
  getFollowupSubIntent(text: string, _lang: string = 'en'): string | null {
    const lower = text.toLowerCase();
    if (/\bmore\s+(detail|info)/i.test(lower)) return 'more_detail';
    if (/\bother\s+point/i.test(lower)) return 'other_points';
    if (/\b(summarize|summary)\b/i.test(lower)) return 'summarize';
    if (/\b(compare|versus|vs)\b/i.test(lower)) return 'compare';
    return null;
  }

  /**
   * Get compare target from query
   */
  getCompareTarget(text: string): { doc1?: string; doc2?: string } | null {
    const match = text.match(/\bcompare\s+(.+?)\s+(and|with|vs\.?|versus)\s+(.+)/i);
    if (match) {
      return { doc1: match[1].trim(), doc2: match[3].trim() };
    }
    return null;
  }

  /**
   * Get doc stats type (count, size, types, etc.)
   * @deprecated Use getDocStatsQueryType() for structured response
   */
  getDocStatsType(text: string): { isPageQuery: boolean; isSlideQuery: boolean; isSheetQuery: boolean; isWordQuery: boolean; isSizeQuery: boolean } {
    const lower = text.toLowerCase();
    // Page count queries: "how many pages", "quantas páginas", "cuántas páginas"
    const isPageQuery = /\b(pages?|páginas?|páginas)\b/i.test(lower) && /\b(how\s+many|count|quantos?|cuántos?|número)\b/i.test(lower);
    // Slide count queries: "how many slides", "quantos slides"
    const isSlideQuery = /\b(slides?|diapositivas)\b/i.test(lower) && /\b(how\s+many|count|quantos?|cuántos?|número)\b/i.test(lower);
    // Sheet count queries: "how many sheets/tabs", "quantas abas/planilhas"
    const isSheetQuery = /\b(sheets?|tabs?|worksheets?|abas?|planilhas?|hojas?)\b/i.test(lower) && /\b(how\s+many|count|quantos?|cuántos?|número)\b/i.test(lower);
    // Word count queries: "how many words", "word count"
    const isWordQuery = /\b(words?|palavras?|palabras?)\b/i.test(lower) && /\b(how\s+many|count|quantos?|cuántos?|número)\b/i.test(lower);
    // Size queries: "how big", "file size", "tamanho"
    const isSizeQuery = /\b(size|big|large|small|bytes?|kb|mb|gb|tamanho|peso)\b/i.test(lower);
    return { isPageQuery, isSlideQuery, isSheetQuery, isWordQuery, isSizeQuery };
  }

  /**
   * Get doc stats type category (count, size, types, breakdown)
   */
  getDocStatsCategory(text: string): string {
    const lower = text.toLowerCase();
    if (/\bhow\s+many\b/i.test(lower)) return 'count';
    if (/\bsize|storage|space\b/i.test(lower)) return 'size';
    if (/\btypes?\s+of\b/i.test(lower)) return 'types';
    if (/\bbreakdown|by\s+type\b/i.test(lower)) return 'breakdown';
    return 'count';
  }

  /**
   * Get file type filter from query
   */
  getFileTypeFilter(text: string): string | null {
    const lower = text.toLowerCase();
    if (/\bpdfs?\b/i.test(lower)) return 'pdf';
    if (/\b(spreadsheets?|xlsx?|excel)\b/i.test(lower)) return 'spreadsheet';
    if (/\b(presentations?|pptx?|slides?|powerpoint)\b/i.test(lower)) return 'presentation';
    if (/\b(images?|pictures?|photos?|png|jpg|jpeg)\b/i.test(lower)) return 'image';
    if (/\b(docs?|documents?|docx?|word)\b/i.test(lower)) return 'document';
    return null;
  }

  /**
   * Get filter type and exclusion flag
   * Returns null if no type is found (fixes truthy {} bug)
   */
  getFilterTypeAndExclusion(text: string): { type: string; exclude: boolean } | null {
    const type = this.getFileTypeFilter(text);
    // CRITICAL: Return null if no type found
    if (!type) return null;
    const hasExclude = /\b(except|excluding|not|without|other\s+than)\b/i.test(text);
    return { type, exclude: hasExclude };
  }

  /**
   * Get folder name from navigation query
   */
  getFolderNameFromNavQuery(text: string): string | null {
    const match = text.match(/\b(go\s+to|navigate\s+to|open|show)\s+(the\s+)?(.+?)\s+(folder|directory)\b/i);
    if (match && match[3]) {
      return match[3].trim();
    }
    const match2 = text.match(/\bin\s+(the\s+)?(.+?)\s+(folder|directory)\b/i);
    if (match2 && match2[2]) {
      return match2[2].trim();
    }
    return null;
  }

  /**
   * Get inventory query type flags for count/list/type queries
   * Used by orchestrator to detect simple inventory queries that don't need RAG
   */
  getInventoryQueryType(text: string): { isCountQuery: boolean; isListQuery: boolean; isTypeQuery: boolean } {
    const lower = text.toLowerCase();

    // Count queries: "how many files", "quantos documentos", "cuantos archivos"
    const isCountQuery = /\b(how\s+many|count|total|number\s+of|quantos?|cuántos?|número\s+de)\b/i.test(lower) &&
                        /\b(file|document|pdf|doc|spreadsheet|arquivo|documento|hoja|planilha)\b/i.test(lower);

    // List queries: "show files", "list documents", "what files", "mostre arquivos"
    const isListQuery = /\b(show|list|display|what|which|mostre|liste|exibir|mostrar|listar|cuales|quais)\b/i.test(lower) &&
                       /\b(file|document|pdf|doc|upload|arquivo|documento|archivos|documentos)\b/i.test(lower);

    // Type queries: "what types", "file formats", "tipos de arquivo"
    const isTypeQuery = /\b(type|format|extension|kind|tipo|formato|extensão)\b/i.test(lower) &&
                       /\b(file|document|arquivo|documento|archivos|documentos)\b/i.test(lower);

    return { isCountQuery, isListQuery, isTypeQuery };
  }

  /**
   * Get inventory query category (all, recent, filtered)
   * Used for sorting/filtering logic
   */
  getInventoryQueryCategory(text: string): string {
    const lower = text.toLowerCase();
    if (/\b(recent|latest|newest|last)\b/i.test(lower)) return 'recent';
    if (/\b(oldest|first|earliest)\b/i.test(lower)) return 'oldest';
    if (/\b(all|every|entire)\b/i.test(lower)) return 'all';
    if (this.getFileTypeFilter(text)) return 'filtered';
    return 'all';
  }

  /**
   * Get newest file type from query
   */
  getNewestFileType(text: string): string | null {
    if (/\bnewest\s+(pdf|spreadsheet|presentation|image|document)\b/i.test(text)) {
      return this.getFileTypeFilter(text);
    }
    return null;
  }

  /**
   * Get type and topic from query
   * Returns null if BOTH type AND topic are not present (fixes truthy {} bug)
   */
  getTypeAndTopic(text: string): { type: string; topic: string } | null {
    const type = this.getFileTypeFilter(text);
    // Extract topic after "about" or "related to"
    const topicMatch = text.match(/\b(about|related\s+to|regarding|on)\s+(.+)/i);
    const topic = topicMatch ? topicMatch[2].trim().replace(/[?.!]+$/, '') : null;

    // CRITICAL: Return null if we don't have BOTH type AND topic
    // This prevents {} from being truthy and misrouting queries
    if (!type || !topic) return null;

    return { type, topic };
  }

  /**
   * Get type selector type from query
   */
  getTypeSelectorType(text: string): string | null {
    return this.getFileTypeFilter(text);
  }

  /**
   * Check if query has ordinal reference (first, second, etc.)
   */
  hasOrdinalReference(text: string): boolean {
    return /\b(first|second|third|fourth|fifth|1st|2nd|3rd|4th|5th|next|previous|last)\b/i.test(text);
  }

  /**
   * Check if query asks to repeat an action
   */
  hasRepeatAction(text: string): boolean {
    return /\b(again|repeat|redo|once\s+more|another\s+time)\b/i.test(text);
  }

  /**
   * Check if text is a financial row pattern
   */
  isFinancialRow(text: string): boolean {
    return /\b(revenue|expense|total|income|profit|sales|cost|margin|ebitda)\b/i.test(text);
  }

  /**
   * Check if query is a folder navigation query
   */
  isFolderNavigationQuery(text: string): boolean {
    return /\b(go\s+to|navigate\s+to|open|show|list)\s+(the\s+)?(.+?)?\s*(folder|directory)\b/i.test(text) ||
           /\bfiles?\s+in\s+(the\s+)?(.+?)\s+(folder|directory)\b/i.test(text);
  }

  /**
   * Check if query is a relevance query
   * @param text The query text
   * @param _language Language code (reserved for future multilingual support)
   */
  isRelevanceQuery(text: string, _language?: string): boolean {
    return /\b(most\s+relevant|most\s+important|best\s+match|top\s+result)\b/i.test(text);
  }

  /**
   * Check if query is asking for files in the same folder (bank-driven)
   */
  isSameFolderQueryBank(text: string): boolean {
    return /\b(what\s+)?other\s+(files?|documents?)\s+(are\s+)?(in|on)\s+(the\s+)?same\s+folder/i.test(text) ||
           /\bfiles?\s+in\s+(this|the\s+same)\s+folder/i.test(text) ||
           /\blist\s+(the\s+)?same\s+folder/i.test(text);
  }
}

// Export singleton
export const runtimePatterns = RuntimePatternsService.getInstance();

// Export class for testing
export { RuntimePatternsService };

// ============================================================================
// RE-EXPORTS FROM dataBankLoader
// Centralize all pattern bank access through runtimePatterns
// Services should import from here, not directly from dataBankLoader
// ============================================================================
export {
  loadPatternBank,
  matchesKeywords,
  matchesKeywordsForLang,
  extractExtensions,
  getAllFileTypeWords,
  isFileOrganizationQuery,
  detectInventoryType,
  detectOperatorFromQuery,
  getLanguageIndicators,
  getDomainKeywords,
  dataBankLoader,
  type MasterPatternBank,
  type PatternFamily,
  type PatternBank,
  type LoadedBank,
} from '../data/dataBankLoader.service';
