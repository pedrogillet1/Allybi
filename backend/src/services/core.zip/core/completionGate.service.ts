/**
 * Completion Gate Service - Pre-Done Validator (VALIDATE-ONLY)
 *
 * CHATGPT PARITY: This gate VALIDATES only, it does NOT transform text.
 * All text transformations must happen in AnswerComposer (single formatter rule).
 *
 * This service:
 * - Detects truncation, dangling markers, constraint violations
 * - Reports issues as warnings for logging/debugging
 * - NEVER modifies the response text
 *
 * If issues are found, they should be logged but the original text is used.
 * The frontend receives the AnswerComposer output unchanged.
 */

import { TruncationDetectorService } from '../utils/truncationDetector.service';

export interface CompletionValidation {
  valid: boolean;
  issues: CompletionIssue[];
  repairs: RepairAction[];
  repairedText?: string;
}

export interface CompletionIssue {
  type: 'TRUNCATION' | 'DANGLING_MARKER' | 'EMPTY_CONTENT' | 'HEADER_ONLY' | 'MISSING_BUTTONS' | 'CONSTRAINT_VIOLATION' | 'BULLET_COUNT' | 'SENTENCE_COUNT';
  severity: 'error' | 'warning';
  description: string;
  location?: string;
}

export interface FormatConstraints {
  bulletCount?: number;
  maxSentences?: number;
  minSentences?: number;
  format?: 'bullets' | 'numbered' | 'paragraph' | 'table';
  maxLength?: number;
}

export interface RepairAction {
  type: string;
  description: string;
  applied: boolean;
}

export interface DoneEventPayload {
  fullAnswer: string;
  formatted?: string;
  intent: string;
  confidence?: number;
  sourceButtons?: { buttons?: Array<{ documentId: string }> } | null;
  constraints?: { buttonsOnly?: boolean; maxItems?: number };
  attachments?: Array<{ id: string; filename: string }>;
  fileList?: { items?: Array<{ documentId: string }> };
  formatConstraints?: FormatConstraints;
}

export class CompletionGateService {
  private readonly truncationDetector: TruncationDetectorService;
  private readonly logger: Console;

  constructor(deps?: { truncationDetector?: TruncationDetectorService; logger?: Console }) {
    this.truncationDetector = deps?.truncationDetector || new TruncationDetectorService();
    this.logger = deps?.logger || console;
  }

  /**
   * Main validation entry point - call before emitting done event
   *
   * CHATGPT PARITY: This method VALIDATES only, it does NOT transform text.
   * All transformations must happen in AnswerComposer.
   */
  validateBeforeEmit(payload: DoneEventPayload): CompletionValidation {
    const issues: CompletionIssue[] = [];
    // Note: repairs array kept for backward compatibility but never populated
    const repairs: RepairAction[] = [];

    // ═══════════════════════════════════════════════════════════════════════════
    // CHECK 1: Truncation Detection (trailing ..., incomplete markers)
    // VALIDATE ONLY - no repair
    // ═══════════════════════════════════════════════════════════════════════════
    const truncationResult = this.truncationDetector.detectTruncation(payload.fullAnswer);
    if (truncationResult.isTruncated) {
      issues.push({
        type: 'TRUNCATION',
        severity: 'warning', // Downgrade to warning - AnswerComposer should have fixed this
        description: `[VALIDATE-ONLY] ${truncationResult.reasons.join(', ')}`,
      });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CHECK 2: Dangling Markdown Markers
    // VALIDATE ONLY - no repair
    // ═══════════════════════════════════════════════════════════════════════════
    const danglingIssues = this.detectDanglingMarkers(payload.fullAnswer);
    issues.push(...danglingIssues);

    // ═══════════════════════════════════════════════════════════════════════════
    // CHECK 3: Empty or Header-Only Content
    // ═══════════════════════════════════════════════════════════════════════════
    const headerOnlyCheck = this.checkHeaderOnly(payload.fullAnswer, payload);
    if (headerOnlyCheck.issue) {
      issues.push(headerOnlyCheck.issue);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CHECK 4: Button-Only Constraint Validation
    // ═══════════════════════════════════════════════════════════════════════════
    if (payload.constraints?.buttonsOnly) {
      const hasButtons = payload.sourceButtons?.buttons && payload.sourceButtons.buttons.length > 0;
      const hasFileList = payload.fileList?.items && payload.fileList.items.length > 0;
      const hasAttachments = payload.attachments && payload.attachments.length > 0;

      if (!hasButtons && !hasFileList && !hasAttachments) {
        issues.push({
          type: 'MISSING_BUTTONS',
          severity: 'error',
          description: 'Button-only response has no buttons, fileList, or attachments',
        });
      }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CHECK 5: Dangling DOC Markers
    // VALIDATE ONLY - no repair
    // ═══════════════════════════════════════════════════════════════════════════
    const danglingDocIssues = this.detectDanglingDocMarkers(payload.fullAnswer);
    issues.push(...danglingDocIssues);

    // ═══════════════════════════════════════════════════════════════════════════
    // CHECK 6: Format Constraint Validation (bullet count, etc.)
    // VALIDATE ONLY - AnswerComposer should have enforced these
    // ═══════════════════════════════════════════════════════════════════════════
    if (payload.formatConstraints) {
      const constraintIssues = this.validateFormatConstraints(payload.fullAnswer, payload.formatConstraints);
      issues.push(...constraintIssues);
    }

    // Log issues for debugging
    if (issues.length > 0) {
      this.logger.warn('[CompletionGate] VALIDATE-ONLY issues detected:', {
        issueCount: issues.length,
        types: issues.map(i => i.type),
        note: 'These issues should have been fixed by AnswerComposer',
      });
    }

    return {
      valid: !issues.some(i => i.severity === 'error'),
      issues,
      repairs,
      // CHATGPT PARITY: Never return repairedText - AnswerComposer is the single formatter
      repairedText: undefined,
    };
  }

  /**
   * Detect dangling markdown markers (VALIDATE ONLY - no repair)
   * CHATGPT PARITY: Detection only, AnswerComposer handles repairs
   */
  private detectDanglingMarkers(text: string): CompletionIssue[] {
    const issues: CompletionIssue[] = [];

    // Check bold markers (**)
    const boldCount = (text.match(/\*\*/g) || []).length;
    if (boldCount % 2 !== 0) {
      issues.push({
        type: 'DANGLING_MARKER',
        severity: 'warning',
        description: '[VALIDATE-ONLY] Unclosed bold marker (**)',
      });
    }

    // Check code fences (```)
    const fenceCount = (text.match(/```/g) || []).length;
    if (fenceCount % 2 !== 0) {
      issues.push({
        type: 'DANGLING_MARKER',
        severity: 'warning',
        description: '[VALIDATE-ONLY] Unclosed code fence (```)',
      });
    }

    // Check inline code (`)
    const backtickCount = (text.match(/(?<!`)`(?!`)/g) || []).length;
    if (backtickCount % 2 !== 0) {
      issues.push({
        type: 'DANGLING_MARKER',
        severity: 'warning',
        description: '[VALIDATE-ONLY] Unclosed inline code (`)',
      });
    }

    // Check unclosed table rows
    const lines = text.split('\n');
    const lastLine = lines[lines.length - 1];
    if (lastLine.includes('|') && !lastLine.trim().endsWith('|')) {
      issues.push({
        type: 'DANGLING_MARKER',
        severity: 'warning',
        description: '[VALIDATE-ONLY] Incomplete table row',
      });
    }

    return issues;
  }

  /**
   * Check for header-only responses (e.g., "You have 30 files:" without listing them)
   */
  private checkHeaderOnly(text: string, payload: DoneEventPayload): { issue?: CompletionIssue } {
    const trimmed = text.trim();

    // Pattern: "You have X file(s):" without any file content after
    const headerPattern = /^(You have|Você tem|Tienes)\s+\d+\s+(file|arquivo|archivo)/i;
    if (headerPattern.test(trimmed) && !trimmed.includes('\n')) {
      // Header-only without line breaks means no content
      const hasButtons = payload.sourceButtons?.buttons && payload.sourceButtons.buttons.length > 0;
      const hasFileList = payload.fileList?.items && payload.fileList.items.length > 0;
      const hasAttachments = payload.attachments && payload.attachments.length > 0;

      if (!hasButtons && !hasFileList && !hasAttachments) {
        return {
          issue: {
            type: 'HEADER_ONLY',
            severity: 'error',
            description: 'Inventory header without file list content',
          },
        };
      }
    }

    // Check for empty content
    if (!trimmed || trimmed.length < 5) {
      const hasButtons = payload.sourceButtons?.buttons && payload.sourceButtons.buttons.length > 0;
      if (!hasButtons && !payload.attachments?.length) {
        return {
          issue: {
            type: 'EMPTY_CONTENT',
            severity: 'error',
            description: 'Response has no meaningful content',
          },
        };
      }
    }

    return {};
  }

  /**
   * Detect dangling DOC markers (VALIDATE ONLY - no repair)
   * CHATGPT PARITY: Detection only, AnswerComposer handles repairs
   */
  private detectDanglingDocMarkers(text: string): CompletionIssue[] {
    const issues: CompletionIssue[] = [];

    // Pattern: {{DOC::id::name without closing }}
    const danglingDocPattern = /\{\{DOC::[^}]*$/gm;
    const matches = text.match(danglingDocPattern);

    if (matches && matches.length > 0) {
      issues.push({
        type: 'DANGLING_MARKER',
        severity: 'warning',
        description: `[VALIDATE-ONLY] ${matches.length} unclosed DOC marker(s)`,
      });
    }

    return issues;
  }

  /**
   * Validate format constraints (VALIDATE ONLY - no repair)
   * CHATGPT PARITY: Detection only, AnswerComposer handles enforcement
   */
  private validateFormatConstraints(text: string, constraints: FormatConstraints): CompletionIssue[] {
    const issues: CompletionIssue[] = [];

    // Bullet count validation
    if (constraints.bulletCount !== undefined) {
      const bulletLines = text.split('\n').filter(line => {
        const trimmed = line.trim();
        return trimmed.startsWith('•') || trimmed.startsWith('-') || trimmed.startsWith('*') || /^\d+\./.test(trimmed);
      });

      const currentCount = bulletLines.length;

      if (currentCount !== constraints.bulletCount) {
        issues.push({
          type: 'BULLET_COUNT',
          severity: 'warning',
          description: `[VALIDATE-ONLY] Bullet count mismatch: ${currentCount} != ${constraints.bulletCount}`,
        });
      }
    }

    // Sentence count validation
    if (constraints.maxSentences !== undefined) {
      const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
      if (sentences.length > constraints.maxSentences) {
        issues.push({
          type: 'SENTENCE_COUNT',
          severity: 'warning',
          description: `[VALIDATE-ONLY] Too many sentences: ${sentences.length} > ${constraints.maxSentences}`,
        });
      }
    }

    if (constraints.minSentences !== undefined) {
      const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
      if (sentences.length < constraints.minSentences) {
        issues.push({
          type: 'SENTENCE_COUNT',
          severity: 'warning',
          description: `[VALIDATE-ONLY] Too few sentences: ${sentences.length} < ${constraints.minSentences}`,
        });
      }
    }

    // Max length validation
    if (constraints.maxLength !== undefined && text.length > constraints.maxLength) {
      issues.push({
        type: 'CONSTRAINT_VIOLATION',
        severity: 'warning',
        description: `[VALIDATE-ONLY] Response too long: ${text.length} > ${constraints.maxLength}`,
      });
    }

    // Table format validation
    if (constraints.format === 'table') {
      const hasMarkdownTable = /\|.*\|.*\|/.test(text) && /\|[\s-]+\|/.test(text);
      if (!hasMarkdownTable) {
        issues.push({
          type: 'CONSTRAINT_VIOLATION',
          severity: 'warning',
          description: '[VALIDATE-ONLY] Table format required but no markdown table found',
        });
      }
    }

    return issues;
  }

  /**
   * Apply repairs and return cleaned text
   */
  applyRepairs(validation: CompletionValidation, originalText: string): string {
    return validation.repairedText || originalText;
  }
}

// Singleton instance for use in orchestrator
let instance: CompletionGateService | null = null;

export function getCompletionGateService(): CompletionGateService {
  if (!instance) {
    instance = new CompletionGateService();
  }
  return instance;
}

export default CompletionGateService;
