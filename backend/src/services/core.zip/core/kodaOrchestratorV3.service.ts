/**
 * Koda Orchestrator V3 - Clean ChatGPT-style Implementation
 *
 * SINGLE BRAIN, SINGLE OUTPUT:
 * - Router is the ONLY place routing decisions are made
 * - Orchestrator trusts router completely, no second-guessing
 * - Two flows: documents (RAG) and non-doc (deterministic)
 * - Streaming and non-streaming share the same plan
 */

import { router, RoutingResult, IntentFamily, Operator, DocScope } from './router.service';
import { getAnswerComposer } from './answerComposer.service';
import KodaRetrievalEngineV3 from './kodaRetrievalEngineV3.service';
import KodaAnswerEngineV3 from './kodaAnswerEngineV3.service';
import { KodaProductHelpServiceV3 } from '../help/kodaProductHelpV3.service';
import { FallbackConfigService } from '../config/fallbackConfig.service';
import { ConversationMemoryService } from '../memory/conversationMemory.service';
import { KodaIntentEngineV3, PredictedIntent } from './kodaIntentEngineV3.service';
import { RoutingTiebreakersService } from './routingTiebreakers.service';
import { UserPreferencesService } from '../user/userPreferences.service';
import { FeedbackLoggerService } from '../analytics/feedbackLogger.service';
import { AnalyticsEngineService } from '../analytics/analyticsEngine.service';
import { DocumentSearchService } from '../analytics/documentSearch.service';
import { KodaAnswerValidationService } from '../validation/kodaAnswerValidation.service';
import { fileSearchService } from '../files/fileInventory.service';
import { getFileActionResolver } from '../files/fileActionResolver.service';
import { createDocMarker } from '../utils/markerUtils';
import prisma from '../../config/database';

import {
  IntentClassificationV3,
  IntentDomain,
  QuestionType,
  QueryScope,
  RetrievedChunk,
} from '../../types/ragV3.types';
import { LanguageCode, IntentHandlerResponse } from '../../types/intentV3.types';
import { StreamEvent, StreamGenerator, ContentEvent, StreamingResult } from '../../types/streaming.types';

// ═══════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════

export interface OrchestratorRequest {
  text: string;
  userId: string;
  conversationId?: string;
  language?: LanguageCode;
  context?: {
    recentMessages?: Array<{ role: string; content: string }>;
    attachedDocumentIds?: string[];
    turnIndex?: number;
  };
  abortSignal?: AbortSignal;
  query?: string;
}

interface ConversationContext {
  lastIntent?: string;
  lastOperator?: string;
  lastDocumentIds?: string[];
  lastDocNames?: string[];
  recentMessages?: Array<{ role: string; content: string }>;
}

interface DocumentInfo {
  id: string;
  filename: string;
  mimeType?: string;
  createdAt?: Date;
}

// Fast availability statuses
const USABLE_STATUSES = ['available', 'enriching', 'ready', 'completed'];

// ═══════════════════════════════════════════════════════════════════════════
// INTENT ADAPTER - Convert routing result to IntentClassificationV3
// ═══════════════════════════════════════════════════════════════════════════

function createIntentClassification(
  routing: RoutingResult,
  query: string,
  targetDocIds?: string[]
): IntentClassificationV3 {
  const getDomain = (): IntentDomain => {
    if (routing.intentFamily === 'documents') return IntentDomain.DOCUMENTS;
    if (routing.intentFamily === 'help') return IntentDomain.PRODUCT;
    if (routing.intentFamily === 'conversation') return IntentDomain.CHITCHAT;
    return IntentDomain.GENERAL;
  };

  const getQuestionType = (): QuestionType => {
    if (routing.operator === 'extract') return QuestionType.EXTRACT;
    if (routing.operator === 'explain') return QuestionType.WHY;
    if (routing.operator === 'summarize') return QuestionType.SUMMARY;
    return QuestionType.OTHER;
  };

  const getScope = (): QueryScope => {
    if (routing.docScope.mode === 'single_doc') return QueryScope.SINGLE_DOC;
    if (routing.docScope.mode === 'multi_doc') return QueryScope.MULTI_DOC;
    return QueryScope.ALL_DOCS;
  };

  return {
    primaryIntent: routing.intentFamily as any,
    domain: getDomain(),
    questionType: getQuestionType(),
    scope: getScope(),
    language: routing.languageLocked,
    requiresRAG: routing.flags.requiresRAG,
    requiresProductHelp: routing.intentFamily === 'help',
    target: targetDocIds?.length
      ? { type: 'BY_ID', documentIds: targetDocIds }
      : { type: 'NONE' },
    documentTargets: targetDocIds || [],
    rawQuery: query,
    confidence: routing.confidence,
    metadata: {
      queryLength: query.length,
      hasContext: false,
      classificationTimeMs: 0,
    },
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// ORCHESTRATOR
// ═══════════════════════════════════════════════════════════════════════════

export class KodaOrchestratorV3 {
  // Core services
  private readonly intentEngine: KodaIntentEngineV3;
  private readonly retrievalEngine: KodaRetrievalEngineV3;
  private readonly answerEngine: KodaAnswerEngineV3;
  private readonly productHelp: KodaProductHelpServiceV3;
  private readonly fallbackConfig: FallbackConfigService;
  private readonly conversationMemory: ConversationMemoryService;
  private readonly tiebreakers: RoutingTiebreakersService;
  private readonly userPreferences: UserPreferencesService;
  private readonly feedbackLogger: FeedbackLoggerService;
  private readonly analyticsEngine: AnalyticsEngineService;
  private readonly documentSearch: DocumentSearchService;
  private readonly validationService: KodaAnswerValidationService;
  private readonly logger: Console;

  constructor(
    services: {
      intentEngine: KodaIntentEngineV3;
      fallbackConfig: FallbackConfigService;
      productHelp: KodaProductHelpServiceV3;
      retrievalEngine: KodaRetrievalEngineV3;
      answerEngine: KodaAnswerEngineV3;
      tiebreakers: RoutingTiebreakersService;
      documentSearch: DocumentSearchService;
      userPreferences: UserPreferencesService;
      conversationMemory: ConversationMemoryService;
      feedbackLogger: FeedbackLoggerService;
      analyticsEngine: AnalyticsEngineService;
      validationService: KodaAnswerValidationService;
    },
    logger?: Console
  ) {
    this.intentEngine = services.intentEngine;
    this.fallbackConfig = services.fallbackConfig;
    this.productHelp = services.productHelp;
    this.retrievalEngine = services.retrievalEngine;
    this.answerEngine = services.answerEngine;
    this.tiebreakers = services.tiebreakers;
    this.documentSearch = services.documentSearch;
    this.userPreferences = services.userPreferences;
    this.conversationMemory = services.conversationMemory;
    this.feedbackLogger = services.feedbackLogger;
    this.analyticsEngine = services.analyticsEngine;
    this.validationService = services.validationService;
    this.logger = logger || console;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // MAIN ORCHESTRATION
  // ═══════════════════════════════════════════════════════════════════════════

  async orchestrate(req: OrchestratorRequest): Promise<IntentHandlerResponse> {
    const startTime = Date.now();

    try {
      // 1. Load context and available docs in parallel
      const [ctx, docs] = await Promise.all([
        this.loadConversationContext(req),
        this.getAvailableDocs(req.userId),
      ]);

      // 2. Single router call - trust the result completely
      const routing = await router.route({
        text: req.text,
        userId: req.userId,
        conversationId: req.conversationId,
        language: req.language,
        hasDocuments: docs.length > 0,
        recentDocIds: ctx.lastDocumentIds,
        recentDocNames: ctx.lastDocNames,
        previousIntent: ctx.lastIntent,
        previousOperator: ctx.lastOperator,
        availableDocs: docs,
      });

      this.logger.info(`[Orchestrator] ${req.text.substring(0, 40)}... → ${routing.intentFamily}/${routing.operator}`);

      // 3. Try deterministic intercept (file actions, help, conversation)
      const intercept = await this.tryDeterministic(req, routing, docs, ctx);
      if (intercept) {
        return this.finalize(intercept, routing, startTime, req);
      }

      // 4. Run appropriate flow based on intent family
      const raw = routing.flags.requiresRAG
        ? await this.runDocumentsFlow(req, routing, docs, ctx)
        : await this.runNonDocFlow(req, routing, ctx);

      return this.finalize(raw, routing, startTime, req);
    } catch (error) {
      this.logger.error('[Orchestrator] Error:', error);
      return this.buildErrorResponse(req, error);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // STREAMING ORCHESTRATION
  // ═══════════════════════════════════════════════════════════════════════════

  async *orchestrateStream(req: OrchestratorRequest): StreamGenerator {
    const startTime = Date.now();

    try {
      // 1. Load context and available docs
      const [ctx, docs] = await Promise.all([
        this.loadConversationContext(req),
        this.getAvailableDocs(req.userId),
      ]);

      // 2. Single router call
      const routing = await router.route({
        text: req.text,
        userId: req.userId,
        conversationId: req.conversationId,
        language: req.language,
        hasDocuments: docs.length > 0,
        recentDocIds: ctx.lastDocumentIds,
        recentDocNames: ctx.lastDocNames,
        previousIntent: ctx.lastIntent,
        previousOperator: ctx.lastOperator,
        availableDocs: docs,
      });

      // Yield intent event
      yield {
        type: 'intent',
        intent: routing.intentFamily,
        confidence: routing.confidence,
        language: routing.languageLocked,
      } as StreamEvent;

      // 3. Try deterministic intercept
      const intercept = await this.tryDeterministic(req, routing, docs, ctx);
      if (intercept) {
        yield { type: 'content', content: intercept.answer } as ContentEvent;
        yield this.buildDoneEvent(intercept, routing, startTime);
        return {
          fullAnswer: intercept.answer,
          intent: routing.intentFamily,
          confidence: routing.confidence,
          documentsUsed: 0,
          processingTime: Date.now() - startTime,
        };
      }

      // 4. Streaming flow
      if (routing.flags.requiresRAG) {
        yield* this.streamDocumentsFlow(req, routing, docs, ctx, startTime);
      } else {
        const raw = await this.runNonDocFlow(req, routing, ctx);
        yield { type: 'content', content: raw.answer } as ContentEvent;
        yield this.buildDoneEvent(raw, routing, startTime);
        return {
          fullAnswer: raw.answer,
          intent: routing.intentFamily,
          confidence: routing.confidence,
          documentsUsed: 0,
          processingTime: Date.now() - startTime,
        };
      }
    } catch (error) {
      this.logger.error('[Orchestrator] Stream error:', error);
      const errorResponse = await this.buildErrorResponse(req, error);
      yield { type: 'content', content: errorResponse.answer } as ContentEvent;
      yield {
        type: 'done',
        formatted: errorResponse.answer,
        timestamp: Date.now(),
      } as StreamEvent;
      return {
        fullAnswer: errorResponse.answer,
        intent: 'error',
        confidence: 0,
        documentsUsed: 0,
        processingTime: Date.now() - startTime,
      };
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // CONTEXT LOADING
  // ═══════════════════════════════════════════════════════════════════════════

  private async loadConversationContext(req: OrchestratorRequest): Promise<ConversationContext> {
    if (!req.conversationId) {
      return { recentMessages: req.context?.recentMessages };
    }

    try {
      const convContext = await this.conversationMemory.getContext(req.conversationId);
      if (!convContext) {
        return { recentMessages: req.context?.recentMessages };
      }

      // Extract last intent/docs from most recent assistant message metadata
      const lastAssistantMsg = convContext.messages
        .filter(m => m.role === 'assistant')
        .slice(-1)[0];

      return {
        lastIntent: (lastAssistantMsg?.metadata as any)?.intent,
        lastDocumentIds: (lastAssistantMsg?.metadata as any)?.sourceDocumentIds,
        recentMessages: convContext.messages.map(m => ({
          role: m.role,
          content: m.content,
        })),
      };
    } catch {
      return { recentMessages: req.context?.recentMessages };
    }
  }

  private async getAvailableDocs(userId: string): Promise<DocumentInfo[]> {
    try {
      return await prisma.document.findMany({
        where: { userId, status: { in: USABLE_STATUSES } },
        select: { id: true, filename: true, mimeType: true, createdAt: true },
        orderBy: { createdAt: 'desc' },
        take: 100,
      });
    } catch {
      return [];
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DETERMINISTIC INTERCEPT (file_actions, help, conversation, doc_stats)
  // ═══════════════════════════════════════════════════════════════════════════

  private async tryDeterministic(
    req: OrchestratorRequest,
    routing: RoutingResult,
    docs: DocumentInfo[],
    ctx: ConversationContext
  ): Promise<IntentHandlerResponse | null> {
    const lang = routing.languageLocked;

    // FILE ACTIONS - deterministic database operations
    if (routing.intentFamily === 'file_actions') {
      return this.handleFileActions(req, routing, docs, ctx);
    }

    // DOC STATS - deterministic metadata queries
    if (routing.intentFamily === 'doc_stats') {
      return this.handleDocStats(req, routing, docs, ctx);
    }

    // HELP - product help templates
    if (routing.intentFamily === 'help') {
      return this.handleHelp(req, routing);
    }

    // CONVERSATION - chitchat responses
    if (routing.intentFamily === 'conversation') {
      return this.handleConversation(req, routing);
    }

    // ERROR or CLARIFY
    if (routing.intentFamily === 'error' || routing.shouldClarify) {
      const fallback = this.fallbackConfig.getFallback('AMBIGUOUS_QUESTION', undefined, lang);
      return this.composeResponse(routing.clarifyQuestion || fallback.text, lang);
    }

    return null;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // FILE ACTIONS HANDLER
  // ═══════════════════════════════════════════════════════════════════════════

  private async handleFileActions(
    req: OrchestratorRequest,
    routing: RoutingResult,
    docs: DocumentInfo[],
    ctx: ConversationContext
  ): Promise<IntentHandlerResponse> {
    const lang = routing.languageLocked;

    // No documents case
    if (docs.length === 0) {
      const fallback = this.fallbackConfig.getFallback('NO_DOCUMENTS', undefined, lang);
      return this.composeResponse(fallback.text, lang);
    }

    // Build inventory for resolver
    const inventory = docs.map(d => ({
      id: d.id,
      filename: d.filename,
      mimeType: d.mimeType || 'application/octet-stream',
      createdAt: d.createdAt || new Date(),
    }));

    // Use FileActionResolver
    const resolver = getFileActionResolver();
    const result = await resolver.resolveFileActionRequest(
      req.text,
      lang,
      {
        lastReferencedFileId: ctx.lastDocumentIds?.[0],
        lastReferencedFileName: ctx.lastDocNames?.[0],
      },
      inventory
    );

    // If we resolved a specific file
    if (result.resolvedDocId) {
      const doc = docs.find(d => d.id === result.resolvedDocId);
      if (doc) {
        const marker = createDocMarker({ id: doc.id, name: doc.filename, ctx: 'open' });
        return {
          answer: marker,
          formatted: marker,
          composedBy: 'AnswerComposerV1',
        };
      }
    }

    // If we have candidates
    if (result.candidates && result.candidates.length > 0) {
      const markers = result.candidates.slice(0, 10).map(c =>
        createDocMarker({ id: c.id, name: c.filename, ctx: 'list' })
      );
      return {
        answer: markers.join('\n'),
        formatted: markers.join('\n'),
        composedBy: 'AnswerComposerV1',
      };
    }

    // Fallback: list recent files
    const recentMarkers = docs.slice(0, 10).map(d =>
      createDocMarker({ id: d.id, name: d.filename, ctx: 'list' })
    );
    return {
      answer: recentMarkers.join('\n'),
      formatted: recentMarkers.join('\n'),
      composedBy: 'AnswerComposerV1',
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DOC STATS HANDLER
  // ═══════════════════════════════════════════════════════════════════════════

  private async handleDocStats(
    req: OrchestratorRequest,
    routing: RoutingResult,
    docs: DocumentInfo[],
    ctx: ConversationContext
  ): Promise<IntentHandlerResponse> {
    const lang = routing.languageLocked;

    // Find target document
    let targetDocId = routing.docScope.docIds?.[0] || ctx.lastDocumentIds?.[0];
    if (!targetDocId && docs.length > 0) {
      targetDocId = docs[0].id;
    }

    if (!targetDocId) {
      const fallback = this.fallbackConfig.getFallback('NO_DOCUMENTS', undefined, lang);
      return this.composeResponse(fallback.text, lang);
    }

    try {
      const doc = await prisma.document.findUnique({
        where: { id: targetDocId },
        select: { filename: true, pageCount: true, metadata: true },
      });

      if (!doc) {
        const fallback = this.fallbackConfig.getFallback('FILE_NOT_FOUND', undefined, lang);
        return this.composeResponse(fallback.text, lang);
      }

      // Extract counts from metadata if not in direct fields
      const metadata = doc.metadata as any || {};
      const pageCount = doc.pageCount || metadata.pageCount;
      const slideCount = metadata.slideCount;
      const sheetCount = metadata.sheetCount;

      let answer: string;
      if (routing.operator === 'count_pages' && pageCount) {
        answer = lang === 'pt'
          ? `O documento "${doc.filename}" tem ${pageCount} páginas.`
          : lang === 'es'
          ? `El documento "${doc.filename}" tiene ${pageCount} páginas.`
          : `The document "${doc.filename}" has ${pageCount} pages.`;
      } else if (routing.operator === 'count_slides' && slideCount) {
        answer = lang === 'pt'
          ? `A apresentação "${doc.filename}" tem ${slideCount} slides.`
          : lang === 'es'
          ? `La presentación "${doc.filename}" tiene ${slideCount} diapositivas.`
          : `The presentation "${doc.filename}" has ${slideCount} slides.`;
      } else if (routing.operator === 'count_sheets' && sheetCount) {
        answer = lang === 'pt'
          ? `A planilha "${doc.filename}" tem ${sheetCount} abas.`
          : lang === 'es'
          ? `La hoja de cálculo "${doc.filename}" tiene ${sheetCount} hojas.`
          : `The spreadsheet "${doc.filename}" has ${sheetCount} sheets.`;
      } else {
        answer = lang === 'pt'
          ? `Não tenho essa informação sobre "${doc.filename}".`
          : lang === 'es'
          ? `No tengo esa información sobre "${doc.filename}".`
          : `I don't have that information about "${doc.filename}".`;
      }

      return this.composeResponse(answer, lang);
    } catch {
      const fallback = this.fallbackConfig.getFallback('GENERIC_ERROR', undefined, lang);
      return this.composeResponse(fallback.text, lang);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // HELP HANDLER
  // ═══════════════════════════════════════════════════════════════════════════

  private async handleHelp(req: OrchestratorRequest, routing: RoutingResult): Promise<IntentHandlerResponse> {
    const lang = routing.languageLocked;
    const helpResult = await this.productHelp.getHelp({ query: req.text, language: lang });
    return this.composeResponse(helpResult.text, lang);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // CONVERSATION HANDLER
  // ═══════════════════════════════════════════════════════════════════════════

  private async handleConversation(req: OrchestratorRequest, routing: RoutingResult): Promise<IntentHandlerResponse> {
    const lang = routing.languageLocked;

    // Simple greeting responses
    const greetings: Record<string, Record<string, string>> = {
      hello: { en: "Hello! I'm Koda, your document assistant. How can I help you today?", pt: "Olá! Sou Koda, seu assistente de documentos. Como posso ajudá-lo hoje?", es: "¡Hola! Soy Koda, tu asistente de documentos. ¿Cómo puedo ayudarte hoy?" },
      thanks: { en: "You're welcome! Let me know if you need anything else.", pt: "De nada! Me avise se precisar de mais alguma coisa.", es: "¡De nada! Avísame si necesitas algo más." },
      bye: { en: "Goodbye! Feel free to come back anytime.", pt: "Tchau! Volte quando quiser.", es: "¡Adiós! Vuelve cuando quieras." },
    };

    const queryLower = req.text.toLowerCase();
    let response = greetings.hello[lang] || greetings.hello.en;

    if (/\b(thanks?|obrigad|gracias)\b/i.test(queryLower)) {
      response = greetings.thanks[lang] || greetings.thanks.en;
    } else if (/\b(bye|tchau|adios|adeus)\b/i.test(queryLower)) {
      response = greetings.bye[lang] || greetings.bye.en;
    }

    return this.composeResponse(response, lang);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DOCUMENTS FLOW (RAG)
  // ═══════════════════════════════════════════════════════════════════════════

  private async runDocumentsFlow(
    req: OrchestratorRequest,
    routing: RoutingResult,
    docs: DocumentInfo[],
    ctx: ConversationContext
  ): Promise<IntentHandlerResponse> {
    const lang = routing.languageLocked;

    // No documents case
    if (docs.length === 0) {
      const fallback = this.fallbackConfig.getFallback('NO_DOCUMENTS', undefined, lang);
      return this.composeResponse(fallback.text, lang);
    }

    // Determine document scope for retrieval
    const targetDocIds = this.resolveDocScope(routing.docScope, ctx, docs);

    // Create intent classification for retrieval engine
    const intentClassification = createIntentClassification(routing, req.text, targetDocIds);

    // Run retrieval
    const chunks = await this.retrievalEngine.retrieve({
      userId: req.userId,
      query: req.text,
      intent: intentClassification,
      language: lang,
      documentIds: targetDocIds,
      lastDocumentIds: ctx.lastDocumentIds,
    });

    // No chunks found
    if (!chunks || chunks.length === 0) {
      const fallback = this.fallbackConfig.getFallback('NO_RELEVANT_CONTENT', undefined, lang);
      return this.composeResponse(fallback.text, lang);
    }

    // Generate answer
    const answerResult = await this.answerEngine.answerWithDocs({
      userId: req.userId,
      query: req.text,
      intent: intentClassification,
      documents: chunks,
      language: lang,
      conversationHistory: ctx.recentMessages?.map(m => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })),
    });

    // Compose final response with sources
    const composer = getAnswerComposer();
    const sourceButtons = chunks.slice(0, 5).map(c => ({
      id: c.documentId,
      name: c.documentName || 'Document',
      pageNumber: c.pageNumber,
    }));

    const composed = composer.compose({
      content: answerResult.answer,
      shape: 'paragraph',
      language: lang,
      sourceButtons,
    });

    return {
      answer: composed.text,
      formatted: composed.text,
      composedBy: 'AnswerComposerV1',
      metadata: {
        documentsUsed: chunks.length,
        sourceDocumentIds: [...new Set(chunks.map(c => c.documentId))],
      },
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // STREAMING DOCUMENTS FLOW
  // ═══════════════════════════════════════════════════════════════════════════

  private async *streamDocumentsFlow(
    req: OrchestratorRequest,
    routing: RoutingResult,
    docs: DocumentInfo[],
    ctx: ConversationContext,
    startTime: number
  ): StreamGenerator {
    const lang = routing.languageLocked;

    // No documents case
    if (docs.length === 0) {
      const fallback = this.fallbackConfig.getFallback('NO_DOCUMENTS', undefined, lang);
      yield { type: 'content', content: fallback.text } as ContentEvent;
      yield this.buildDoneEvent(this.composeResponse(fallback.text, lang), routing, startTime);
      return {
        fullAnswer: fallback.text,
        intent: routing.intentFamily,
        confidence: routing.confidence,
        documentsUsed: 0,
        processingTime: Date.now() - startTime,
      };
    }

    // Determine document scope
    const targetDocIds = this.resolveDocScope(routing.docScope, ctx, docs);
    const intentClassification = createIntentClassification(routing, req.text, targetDocIds);

    // Run retrieval
    const chunks = await this.retrievalEngine.retrieve({
      userId: req.userId,
      query: req.text,
      intent: intentClassification,
      language: lang,
      documentIds: targetDocIds,
      lastDocumentIds: ctx.lastDocumentIds,
    });

    // No chunks found
    if (!chunks || chunks.length === 0) {
      const fallback = this.fallbackConfig.getFallback('NO_RELEVANT_CONTENT', undefined, lang);
      yield { type: 'content', content: fallback.text } as ContentEvent;
      yield this.buildDoneEvent(this.composeResponse(fallback.text, lang), routing, startTime);
      return {
        fullAnswer: fallback.text,
        intent: routing.intentFamily,
        confidence: routing.confidence,
        documentsUsed: 0,
        processingTime: Date.now() - startTime,
      };
    }

    // Stream answer generation
    let fullAnswer = '';
    const answerStream = this.answerEngine.streamAnswerWithDocsAsync({
      userId: req.userId,
      query: req.text,
      intent: intentClassification,
      documents: chunks,
      language: lang,
      conversationHistory: ctx.recentMessages?.map(m => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })),
      abortSignal: req.abortSignal,
    });

    for await (const event of answerStream) {
      if (event.type === 'content') {
        fullAnswer += (event as ContentEvent).content;
        yield event;
      }
    }

    // Build done event with sources
    const sourceButtons = chunks.slice(0, 5).map(c => ({
      id: c.documentId,
      name: c.documentName || 'Document',
      pageNumber: c.pageNumber,
    }));

    const response: IntentHandlerResponse = {
      answer: fullAnswer,
      formatted: fullAnswer,
      composedBy: 'AnswerComposerV1',
      metadata: {
        documentsUsed: chunks.length,
        sourceDocumentIds: [...new Set(chunks.map(c => c.documentId))],
      },
    };

    yield {
      type: 'done',
      formatted: fullAnswer,
      intent: routing.intentFamily,
      operator: routing.operator,
      confidence: routing.confidence,
      language: lang,
      processingTime: Date.now() - startTime,
      attachments: [{ type: 'sourceButtons', buttons: sourceButtons }],
      citations: chunks.slice(0, 5).map(c => ({
        documentId: c.documentId,
        documentName: c.documentName,
        pageNumber: c.pageNumber,
      })),
      timestamp: Date.now(),
    } as StreamEvent;

    // Save context
    if (req.conversationId) {
      await this.saveConversationContext(req.conversationId, routing, response);
    }

    return {
      fullAnswer,
      intent: routing.intentFamily,
      confidence: routing.confidence,
      documentsUsed: chunks.length,
      processingTime: Date.now() - startTime,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // NON-DOC FLOW (reasoning without documents)
  // ═══════════════════════════════════════════════════════════════════════════

  private async runNonDocFlow(
    req: OrchestratorRequest,
    routing: RoutingResult,
    ctx: ConversationContext
  ): Promise<IntentHandlerResponse> {
    const lang = routing.languageLocked;
    const intentClassification = createIntentClassification(routing, req.text, []);

    const answer = await this.answerEngine.answer({
      userId: req.userId,
      query: req.text,
      intent: intentClassification,
      language: lang,
    });

    return this.composeResponse(answer, lang);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // UTILITIES
  // ═══════════════════════════════════════════════════════════════════════════

  private resolveDocScope(docScope: DocScope, ctx: ConversationContext, docs: DocumentInfo[]): string[] | undefined {
    if (docScope.mode === 'single_doc' && docScope.docIds?.length) {
      return docScope.docIds;
    }
    if (docScope.mode === 'multi_doc' && docScope.docIds?.length) {
      return docScope.docIds;
    }
    if (docScope.mode === 'single_doc' && ctx.lastDocumentIds?.length) {
      return ctx.lastDocumentIds;
    }
    return undefined; // workspace mode - search all
  }

  private composeResponse(text: string, lang: string): IntentHandlerResponse {
    const composer = getAnswerComposer();
    const composed = composer.composeSimpleText(text, lang as 'en' | 'pt' | 'es');
    return {
      answer: composed.content,
      formatted: composed.content,
      composedBy: 'AnswerComposerV1',
    };
  }

  private buildDoneEvent(response: IntentHandlerResponse, routing: RoutingResult, startTime: number): StreamEvent {
    return {
      type: 'done',
      formatted: response.formatted || response.answer,
      intent: routing.intentFamily,
      operator: routing.operator,
      confidence: routing.confidence,
      language: routing.languageLocked,
      processingTime: Date.now() - startTime,
      attachments: [],
      citations: [],
      timestamp: Date.now(),
    } as StreamEvent;
  }

  private finalize(
    response: IntentHandlerResponse,
    routing: RoutingResult,
    startTime: number,
    req: OrchestratorRequest
  ): IntentHandlerResponse {
    const finalResponse = {
      ...response,
      metadata: {
        ...response.metadata,
        intent: routing.intentFamily,
        operator: routing.operator,
        confidence: routing.confidence,
        processingTime: Date.now() - startTime,
      },
    };

    // Save conversation context
    if (req.conversationId) {
      this.saveConversationContext(req.conversationId, routing, finalResponse).catch(() => {});
    }

    return finalResponse;
  }

  private async saveConversationContext(
    conversationId: string,
    routing: RoutingResult,
    response: IntentHandlerResponse
  ): Promise<void> {
    try {
      await this.conversationMemory.updateMetadata(conversationId, {
        lastIntent: routing.intentFamily,
        lastDocumentIds: response.metadata?.sourceDocumentIds || [],
      });
    } catch {
      // Ignore
    }
  }

  private async buildErrorResponse(req: OrchestratorRequest, error: any): Promise<IntentHandlerResponse> {
    const lang = req.language || 'en';
    const fallback = this.fallbackConfig.getFallback('GENERIC_ERROR', undefined, lang);
    return this.composeResponse(fallback.text, lang);
  }
}

export default KodaOrchestratorV3;
