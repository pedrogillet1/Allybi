/**
 * Query Normalizer Service
 *
 * Provides normalization and fuzzy matching for typo tolerance.
 * Must be applied BEFORE pattern matching in:
 * - languageDetector
 * - contentGuard
 * - operator/intent matching
 */

// ═══════════════════════════════════════════════════════════════════════════
// CANONICAL TOKENS - High-value words for fuzzy matching
// ═══════════════════════════════════════════════════════════════════════════

const CANONICAL_TOKENS: Record<string, string[]> = {
  // Operators (EN)
  verbs_en: [
    'summarize', 'summarise', 'extract', 'compare', 'compute', 'calculate',
    'locate', 'find', 'open', 'show', 'list', 'display', 'filter', 'sort',
    'group', 'explain', 'analyze', 'analyse', 'review', 'highlight',
  ],
  // Operators (PT)
  verbs_pt: [
    'resumir', 'extrair', 'comparar', 'calcular', 'localizar', 'encontrar',
    'abrir', 'mostrar', 'listar', 'exibir', 'filtrar', 'ordenar', 'agrupar',
    'explicar', 'analisar', 'revisar', 'destacar',
  ],
  // Document types (EN)
  doc_types_en: [
    'document', 'documents', 'file', 'files', 'pdf', 'spreadsheet',
    'presentation', 'report', 'contract', 'invoice', 'statement',
  ],
  // Document types (PT)
  doc_types_pt: [
    'documento', 'documentos', 'arquivo', 'arquivos', 'planilha',
    'apresentação', 'relatório', 'contrato', 'fatura', 'extrato',
  ],
  // Content nouns (EN)
  content_en: [
    'topics', 'summary', 'overview', 'conclusion', 'findings', 'points',
    'revenue', 'expenses', 'profit', 'margin', 'total', 'average',
  ],
  // Content nouns (PT)
  content_pt: [
    'tópicos', 'resumo', 'visão', 'conclusão', 'achados', 'pontos',
    'receita', 'despesas', 'lucro', 'margem', 'total', 'média',
  ],
  // Question words (EN)
  questions_en: ['what', 'where', 'which', 'how', 'when', 'why'],
  // Question words (PT)
  questions_pt: ['qual', 'onde', 'como', 'quando', 'porque', 'quais'],
};

// Flatten all canonical tokens
const ALL_CANONICAL_TOKENS = new Set(
  Object.values(CANONICAL_TOKENS).flat().map(t => t.toLowerCase())
);

// ═══════════════════════════════════════════════════════════════════════════
// COMMON TYPO CORRECTIONS - Direct mappings for frequent typos
// ═══════════════════════════════════════════════════════════════════════════

const COMMON_TYPO_CORRECTIONS: Record<string, string> = {
  // EN verbs
  'summerize': 'summarize',
  'sumarize': 'summarize',
  'summrize': 'summarize',
  'summarzie': 'summarize',
  'extarct': 'extract',
  'exract': 'extract',
  'extrat': 'extract',
  'compre': 'compare',
  'compar': 'compare',
  'comprae': 'compare',
  'calcualte': 'calculate',
  'claculate': 'calculate',
  'locat': 'locate',
  'locaet': 'locate',
  'opne': 'open',
  'oepn': 'open',
  'shwo': 'show',
  'hsow': 'show',
  'litst': 'list',
  'lsit': 'list',
  'displya': 'display',
  'diplay': 'display',
  'fitler': 'filter',
  'filer': 'filter',
  'srot': 'sort',
  'sotr': 'sort',
  'gruop': 'group',
  'gropu': 'group',
  'expain': 'explain',
  'expalin': 'explain',
  'anaylze': 'analyze',
  'analize': 'analyze',

  // EN nouns
  'docuemnt': 'document',
  'documnet': 'document',
  'docment': 'document',
  'fiel': 'file',
  'flie': 'file',
  'spredsheet': 'spreadsheet',
  'spreadhseet': 'spreadsheet',
  'presnetation': 'presentation',
  'presenation': 'presentation',
  'repotr': 'report',
  'reprot': 'report',
  'revnue': 'revenue',
  'reveune': 'revenue',
  'expesnes': 'expenses',
  'expneses': 'expenses',
  'toatl': 'total',
  'totla': 'total',
  'summray': 'summary',
  'sumary': 'summary',
  'overveiw': 'overview',
  'overivew': 'overview',

  // PT verbs
  'resumri': 'resumir',
  'resmuir': 'resumir',
  'extrari': 'extrair',
  'extarri': 'extrair',
  'comparar': 'comparar',
  'comaprar': 'comparar',

  // PT nouns
  'documetno': 'documento',
  'docuemnto': 'documento',
  'arquvio': 'arquivo',
  'arqiuvo': 'arquivo',
  'planilah': 'planilha',
  'palinhla': 'planilha',
  'relatrorio': 'relatório',
  'realtório': 'relatório',
};

// ═══════════════════════════════════════════════════════════════════════════
// DAMERAU-LEVENSHTEIN DISTANCE
// ═══════════════════════════════════════════════════════════════════════════

function damerauLevenshteinDistance(a: string, b: string): number {
  const lenA = a.length;
  const lenB = b.length;

  if (lenA === 0) return lenB;
  if (lenB === 0) return lenA;

  // Create distance matrix
  const d: number[][] = Array.from({ length: lenA + 1 }, () =>
    Array.from({ length: lenB + 1 }, () => 0)
  );

  for (let i = 0; i <= lenA; i++) d[i][0] = i;
  for (let j = 0; j <= lenB; j++) d[0][j] = j;

  for (let i = 1; i <= lenA; i++) {
    for (let j = 1; j <= lenB; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;

      d[i][j] = Math.min(
        d[i - 1][j] + 1,      // deletion
        d[i][j - 1] + 1,      // insertion
        d[i - 1][j - 1] + cost // substitution
      );

      // Transposition
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
        d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + cost);
      }
    }
  }

  return d[lenA][lenB];
}

// ═══════════════════════════════════════════════════════════════════════════
// FUZZY MATCHING
// ═══════════════════════════════════════════════════════════════════════════

interface FuzzyMatch {
  original: string;
  corrected: string;
  distance: number;
  confidence: number;
}

function findBestFuzzyMatch(word: string, maxDistance: number = 2): FuzzyMatch | null {
  const lower = word.toLowerCase();

  // Skip if already canonical
  if (ALL_CANONICAL_TOKENS.has(lower)) {
    return null;
  }

  // Check common typo corrections first
  if (COMMON_TYPO_CORRECTIONS[lower]) {
    return {
      original: word,
      corrected: COMMON_TYPO_CORRECTIONS[lower],
      distance: 1,
      confidence: 0.95,
    };
  }

  // Only fuzzy match words of reasonable length (4-15 chars)
  if (word.length < 4 || word.length > 15) {
    return null;
  }

  let bestMatch: FuzzyMatch | null = null;
  let bestDistance = maxDistance + 1;

  for (const canonical of ALL_CANONICAL_TOKENS) {
    // Skip if length difference is too large
    if (Math.abs(canonical.length - lower.length) > maxDistance) {
      continue;
    }

    const distance = damerauLevenshteinDistance(lower, canonical);

    if (distance <= maxDistance && distance < bestDistance) {
      bestDistance = distance;
      bestMatch = {
        original: word,
        corrected: canonical,
        distance,
        confidence: 1 - (distance / Math.max(word.length, canonical.length)),
      };
    }
  }

  return bestMatch;
}

// ═══════════════════════════════════════════════════════════════════════════
// QUERY NORMALIZATION
// ═══════════════════════════════════════════════════════════════════════════

export interface NormalizedQuery {
  original: string;
  normalized: string;
  tokens: string[];
  corrections: FuzzyMatch[];
  language?: 'en' | 'pt' | 'es';
}

/**
 * Normalize a query for routing:
 * 1. Lowercase
 * 2. Strip diacritics (for matching)
 * 3. Collapse whitespace
 * 4. Normalize punctuation
 * 5. Apply typo corrections
 */
export function normalizeQuery(text: string, applyFuzzy: boolean = true): NormalizedQuery {
  const original = text;

  // Step 1: Lowercase
  let normalized = text.toLowerCase();

  // Step 2: Strip diacritics (but keep original for reference)
  const stripped = normalized.normalize('NFD').replace(/[\u0300-\u036f]/g, '');

  // Step 3: Collapse whitespace
  normalized = normalized.replace(/\s+/g, ' ').trim();

  // Step 4: Normalize punctuation (but preserve important ones)
  normalized = normalized
    .replace(/['']/g, "'")
    .replace(/[""]/g, '"')
    .replace(/…/g, '...');

  // Step 5: Tokenize
  const tokens = normalized
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter(t => t.length > 0);

  // Step 6: Apply fuzzy corrections
  const corrections: FuzzyMatch[] = [];

  if (applyFuzzy) {
    const correctedTokens: string[] = [];

    for (const token of tokens) {
      const match = findBestFuzzyMatch(token);
      if (match && match.confidence >= 0.7) {
        corrections.push(match);
        correctedTokens.push(match.corrected);
      } else {
        correctedTokens.push(token);
      }
    }

    // Rebuild normalized string with corrections
    if (corrections.length > 0) {
      let correctedText = normalized;
      for (const corr of corrections) {
        correctedText = correctedText.replace(
          new RegExp(`\\b${corr.original}\\b`, 'gi'),
          corr.corrected
        );
      }
      normalized = correctedText;
    }
  }

  return {
    original,
    normalized,
    tokens,
    corrections,
  };
}

/**
 * Quick check if a query has potential typos
 */
export function hasLikelyTypos(text: string): boolean {
  const { corrections } = normalizeQuery(text, true);
  return corrections.length > 0;
}

/**
 * Get all corrections for a query
 */
export function getTypoCorrections(text: string): FuzzyMatch[] {
  const { corrections } = normalizeQuery(text, true);
  return corrections;
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════════════════

export {
  CANONICAL_TOKENS,
  COMMON_TYPO_CORRECTIONS,
  damerauLevenshteinDistance,
  findBestFuzzyMatch,
  ALL_CANONICAL_TOKENS,
};
