/**
 * KODA V3 Language Detector Service - BANK-DRIVEN
 *
 * Fixes from certification failure analysis:
 * 1. Tokenization + word-boundary matching (stops substring false positives)
 * 2. Weighted scores (rare/diagnostic tokens count more)
 * 3. Confidence threshold + 'unknown' output
 * 4. Conversation-language fallback when unknown
 * 5. Reduced EN generic indicators (avoid EN dominating)
 * 6. Proper accent/punctuation normalization
 *
 * BANK-DRIVEN: All language indicators loaded from pattern_bank_master.json
 * NO HARDCODED PATTERNS - weights derived from strong/medium/weak categories
 */

import { LanguageCode } from '../../types/intentV3.types';
import { loadPatternBank } from './runtimePatterns.service';

/**
 * Extended result with confidence and debug info
 */
export interface LanguageResult {
  lang: LanguageCode | 'unknown';
  confidence: number;  // 0..1
  scores: { en: number; pt: number; es: number };
  signals: string[];   // which indicators matched (for debugging)
}

/**
 * Interface for language detection
 * Allows swapping detection implementation (heuristic, ML-based, external API)
 */
export interface ILanguageDetector {
  detect(text: string, conversationLanguage?: LanguageCode): Promise<LanguageCode>;
  detectWithConfidence(text: string, conversationLanguage?: LanguageCode): Promise<LanguageResult>;
}

/**
 * Weighted indicator with diagnostic value
 */
interface WeightedIndicator {
  pattern: string;
  weight: number;  // 1-5, higher = more diagnostic
  isPhrase?: boolean;  // true if multi-word phrase
}

/**
 * BANK-DRIVEN implementation with:
 * - Token-based matching with word boundaries
 * - Weighted scores for indicators (loaded from pattern bank)
 * - Confidence thresholds
 * - Conversation language fallback
 */
export class DefaultLanguageDetector implements ILanguageDetector {
  // Minimum total score to make a decision (below this = unknown)
  // Lowered to 1 for better sensitivity with single-indicator queries
  private readonly MIN_TOTAL_SCORE = 1;
  // Minimum margin between top and second language (below this = unknown)
  // Lowered to 1.0 for clearer language decisions
  private readonly MIN_MARGIN = 1.0;
  // Confidence scaling factor
  private readonly CONFIDENCE_SCALE = 10;

  // ═══════════════════════════════════════════════════════════════════════════
  // BANK-DRIVEN INDICATORS - Loaded from pattern_bank_master.json
  // Weights: strong=5, medium=3, weak=1
  // ═══════════════════════════════════════════════════════════════════════════
  private ptIndicators: WeightedIndicator[] = [];
  private esIndicators: WeightedIndicator[] = [];
  private enIndicators: WeightedIndicator[] = [];
  private indicatorsLoaded = false;

  /**
   * Load indicators from pattern bank (lazy initialization)
   */
  private loadIndicatorsFromBank(): void {
    if (this.indicatorsLoaded) return;

    try {
      const bank = loadPatternBank();
      const indicators = bank.languageIndicators;

      // Convert bank format to WeightedIndicator format
      // strong = weight 5, medium = weight 3, weak = weight 1
      this.ptIndicators = this.convertBankIndicators(indicators.pt);
      this.esIndicators = this.convertBankIndicators(indicators.es);
      this.enIndicators = this.convertBankIndicators(indicators.en);

      this.indicatorsLoaded = true;
      console.log('[LanguageDetector] Loaded indicators from pattern bank');
    } catch (err) {
      console.error('[LanguageDetector] Failed to load from bank, using fallback');
      // Fallback to minimal indicators if bank fails
      this.ptIndicators = [{ pattern: 'você', weight: 5 }, { pattern: 'mostre', weight: 5 }];
      this.esIndicators = [{ pattern: 'usted', weight: 5 }, { pattern: 'cuántos', weight: 5 }];
      this.enIndicators = [{ pattern: 'please', weight: 4 }, { pattern: 'show me', weight: 4, isPhrase: true }];
      this.indicatorsLoaded = true;
    }
  }

  /**
   * Convert bank indicators (strong/medium/weak arrays) to WeightedIndicator array
   */
  private convertBankIndicators(langIndicators: { strong: string[]; medium: string[]; weak: string[] }): WeightedIndicator[] {
    const result: WeightedIndicator[] = [];

    // Strong indicators get weight 5
    for (const pattern of langIndicators.strong || []) {
      result.push({
        pattern,
        weight: 5,
        isPhrase: pattern.includes(' '),
      });
    }

    // Medium indicators get weight 3
    for (const pattern of langIndicators.medium || []) {
      result.push({
        pattern,
        weight: 3,
        isPhrase: pattern.includes(' '),
      });
    }

    // Weak indicators get weight 1
    for (const pattern of langIndicators.weak || []) {
      result.push({
        pattern,
        weight: 1,
        isPhrase: pattern.includes(' '),
      });
    }

    return result;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // LEGACY HARDCODED INDICATORS - REMOVED
  // All indicators now loaded from pattern_bank_master.json
  // See: loadIndicatorsFromBank() above
  // All indicators now loaded from pattern_bank_master.json

  /**
   * Create a language instruction for LLM prompts
   */
  createLanguageInstruction(lang: string): string {
    const instructions: Record<string, string> = {
      en: 'Respond in English.',
      pt: 'Responda em português brasileiro.',
      es: 'Responde en español.',
    };
    return instructions[lang] || instructions.en;
  }

  /**
   * Normalize text for matching:
   * 1. Lowercase
   * 2. Strip diacritics (for fallback matching)
   * 3. Normalize whitespace
   */
  private normalizeText(text: string): { original: string; stripped: string; tokens: string[] } {
    const lower = text.toLowerCase();

    // Strip diacritics for fallback matching
    const stripped = lower.normalize('NFD').replace(/[\u0300-\u036f]/g, '');

    // Tokenize: split on whitespace and punctuation, keep words only
    const tokens = lower
      .replace(/[^\p{L}\p{N}\s]/gu, ' ')  // Replace non-letter/number with space
      .split(/\s+/)
      .filter(t => t.length > 0);

    return { original: lower, stripped, tokens };
  }

  /**
   * Check if a pattern matches using word boundaries
   */
  private matchesPattern(
    indicator: WeightedIndicator,
    normalized: { original: string; stripped: string; tokens: string[] }
  ): boolean {
    const { original, stripped, tokens } = normalized;
    const pattern = indicator.pattern.toLowerCase();

    if (indicator.isPhrase) {
      // Phrase matching: check if phrase appears as substring with word boundaries
      const phraseRegex = new RegExp(`\\b${this.escapeRegex(pattern)}\\b`, 'i');
      return phraseRegex.test(original) || phraseRegex.test(stripped);
    } else {
      // Single word: check token list for exact match
      const strippedPattern = pattern.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      return tokens.includes(pattern) || tokens.includes(strippedPattern);
    }
  }

  /**
   * Escape special regex characters
   */
  private escapeRegex(str: string): string {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /**
   * Calculate weighted score for a language
   */
  private calculateScore(
    indicators: WeightedIndicator[],
    normalized: { original: string; stripped: string; tokens: string[] }
  ): { score: number; matches: string[] } {
    let score = 0;
    const matches: string[] = [];

    for (const indicator of indicators) {
      if (this.matchesPattern(indicator, normalized)) {
        score += indicator.weight;
        matches.push(`${indicator.pattern}(+${indicator.weight})`);
      }
    }

    return { score, matches };
  }

  /**
   * Detect language with full confidence information
   */
  async detectWithConfidence(
    text: string,
    conversationLanguage?: LanguageCode
  ): Promise<LanguageResult> {
    // Load indicators from bank (lazy initialization)
    this.loadIndicatorsFromBank();

    const normalized = this.normalizeText(text);

    // Calculate weighted scores
    const ptResult = this.calculateScore(this.ptIndicators, normalized);
    const esResult = this.calculateScore(this.esIndicators, normalized);
    const enResult = this.calculateScore(this.enIndicators, normalized);

    const scores = {
      pt: ptResult.score,
      es: esResult.score,
      en: enResult.score,
    };

    const signals = [
      ...ptResult.matches.map(m => `PT:${m}`),
      ...esResult.matches.map(m => `ES:${m}`),
      ...enResult.matches.map(m => `EN:${m}`),
    ];

    const totalScore = scores.pt + scores.es + scores.en;

    // Find top two languages
    const sortedLangs = Object.entries(scores)
      .sort(([, a], [, b]) => b - a) as [LanguageCode, number][];

    const [topLang, topScore] = sortedLangs[0];
    const [, secondScore] = sortedLangs[1];
    const margin = topScore - secondScore;

    // Calculate confidence (0-1)
    const confidence = totalScore > 0
      ? Math.min(1, (topScore / this.CONFIDENCE_SCALE) * (margin / Math.max(1, topScore)))
      : 0;

    // Decision logic with thresholds
    if (totalScore < this.MIN_TOTAL_SCORE) {
      // Not enough signal - use fallback
      return {
        lang: conversationLanguage || 'unknown',
        confidence: 0,
        scores,
        signals: [...signals, 'FALLBACK:low_total_score'],
      };
    }

    if (margin < this.MIN_MARGIN) {
      // Too close to call - use conversation language or unknown
      return {
        lang: conversationLanguage || 'unknown',
        confidence: confidence * 0.5,  // Reduce confidence for ties
        scores,
        signals: [...signals, 'FALLBACK:low_margin'],
      };
    }

    return {
      lang: topLang,
      confidence,
      scores,
      signals,
    };
  }

  /**
   * Simple detect method for backward compatibility
   * Returns LanguageCode, falling back to 'en' if unknown
   */
  async detect(text: string, conversationLanguage?: LanguageCode): Promise<LanguageCode> {
    const result = await this.detectWithConfidence(text, conversationLanguage);

    if (result.lang === 'unknown') {
      // Final fallback chain:
      // 1. Conversation language (if provided)
      // 2. Default to English
      return conversationLanguage || 'en';
    }

    return result.lang as LanguageCode;
  }
}

// Use container.getLanguageDetector() instead of singleton
// Singleton removed - use DI container
export default DefaultLanguageDetector;
