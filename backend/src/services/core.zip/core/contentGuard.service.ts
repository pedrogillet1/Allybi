/**
 * ContentGuard Service — Bank-driven with two-signal fallback
 *
 * SINGLE SOURCE OF TRUTH for classifying:
 *  - content questions (about what's inside docs)  → documents/RAG
 *  - file actions (navigation/management)          → file_actions (no RAG)
 *
 * Must be used by any layer that might route to file_actions.
 */

import * as fs from 'fs';
import * as path from 'path';
import { isFileOrganizationQuery } from './runtimePatterns.service';

export type LanguageCode = 'en' | 'pt' | 'es';

const BANK_BASE = path.join(__dirname, '../../../data_banks');

const BANK_PATHS = {
  content: {
    en: path.join(BANK_BASE, 'triggers/content_guard.en.json'),
    pt: path.join(BANK_BASE, 'triggers/content_guard.pt.json'),
  },
  negative: {
    en: path.join(BANK_BASE, 'negatives/not_content_guard.en.json'),
    pt: path.join(BANK_BASE, 'negatives/not_content_guard.pt.json'),
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// Internal state (lazy-loaded)
// ─────────────────────────────────────────────────────────────────────────────

let contentPatternsEN: RegExp[] | null = null;
let contentPatternsPT: RegExp[] | null = null;
let negativePatternsEN: RegExp[] | null = null;
let negativePatternsPT: RegExp[] | null = null;

let bankLoadStatus = {
  enContentLoaded: 0,
  ptContentLoaded: 0,
  enNegativeLoaded: 0,
  ptNegativeLoaded: 0,
};

// ─────────────────────────────────────────────────────────────────────────────
// Normalization helpers
// ─────────────────────────────────────────────────────────────────────────────

function foldDiacritics(str: string): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * If pattern looks like a regex, compile as-is.
 * Otherwise compile as a case-insensitive literal substring regex.
 */
function patternToRegex(pattern: string): RegExp {
  const looksLikeRegex = /[.*+?^${}()|[\]\\]/.test(pattern);
  return looksLikeRegex ? new RegExp(pattern, 'i') : new RegExp(escapeRegex(pattern), 'i');
}

function loadBankPatterns(bankPath: string): RegExp[] {
  try {
    if (!fs.existsSync(bankPath)) return [];
    const bankData = JSON.parse(fs.readFileSync(bankPath, 'utf-8'));

    const out: RegExp[] = [];
    if (bankData?.families) {
      for (const familyKey of Object.keys(bankData.families)) {
        const family = bankData.families[familyKey];
        const patterns: unknown = family?.patterns;
        if (Array.isArray(patterns)) {
          for (const p of patterns) {
            if (typeof p !== 'string') continue;
            try {
              out.push(patternToRegex(p));
            } catch {
              // Skip invalid regex patterns safely
            }
          }
        }
      }
    }
    return out;
  } catch {
    return [];
  }
}

function initializePatterns(): void {
  if (contentPatternsEN === null) {
    contentPatternsEN = loadBankPatterns(BANK_PATHS.content.en);
    bankLoadStatus.enContentLoaded = contentPatternsEN.length;
  }
  if (contentPatternsPT === null) {
    contentPatternsPT = loadBankPatterns(BANK_PATHS.content.pt);
    bankLoadStatus.ptContentLoaded = contentPatternsPT.length;
  }
  if (negativePatternsEN === null) {
    negativePatternsEN = loadBankPatterns(BANK_PATHS.negative.en);
    bankLoadStatus.enNegativeLoaded = negativePatternsEN.length;
  }
  if (negativePatternsPT === null) {
    negativePatternsPT = loadBankPatterns(BANK_PATHS.negative.pt);
    bankLoadStatus.ptNegativeLoaded = negativePatternsPT.length;
  }
}

function matchesAny(query: string, patterns: RegExp[]): boolean {
  const norm = query.toLowerCase().trim();
  const folded = foldDiacritics(query).trim();

  for (const re of patterns) {
    if (re.test(norm) || re.test(folded)) return true;
  }
  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// Lightweight language guess (only for fallback behavior)
// Router can override by passing language explicitly.
// ─────────────────────────────────────────────────────────────────────────────

function detectLanguage(query: string): LanguageCode {
  const q = query.toLowerCase();

  // PT
  if (/\b(quais?|qual|são|está|onde|você|voce|meus?|minha|documentos?|arquivos?|resuma|explique|analise|tópicos?|paginas?|páginas?|planilhas?)\b/i.test(q)) {
    return 'pt';
  }
  // ES (minimal)
  if (/\b(qué|cuál|cuáles|dónde|cómo|archivos?|presenta|explica)\b/i.test(q)) {
    return 'es';
  }
  return 'en';
}

// ─────────────────────────────────────────────────────────────────────────────
// Two-signal fallback (when banks didn't match)
// ─────────────────────────────────────────────────────────────────────────────

const CONTENT_VERBS_EN = new Set([
  'summarize','summarise','explain','describe','cover','discuss','mention','define',
  'argue','claim','state','conclude','analyze','analyse','compare','contrast','extract',
  'outline','detail','elaborate','clarify','interpret','review','recap','highlight',
  'identify','address','talk about','go over','break down','walk through','point out',
  'touch on','delve into',
]);

const CONTENT_VERBS_PT = new Set([
  'resumir','resuma','explicar','explique','descrever','descreva','cobrir','cobre',
  'discutir','discute','mencionar','menciona','definir','defina','argumentar','argumenta',
  'afirmar','afirma','concluir','conclui','analisar','analise','comparar','compare',
  'extrair','extraia','detalhar','detalhe','elaborar','elabore','clarificar','clarifique',
  'interpretar','interprete','revisar','revise','destacar','destaque','identificar',
  'identifique','abordar','aborda','falar sobre','tratar de','dizer sobre',
]);

const CONTENT_NOUNS_EN = new Set([
  'topics','topic','themes','theme','points','point','takeaways','takeaway','findings','finding',
  'conclusions','conclusion','arguments','argument','claims','claim','thesis','summary','overview',
  'gist','essence','meaning','insights','insight','highlights','highlight','key points','main points',
  'analysis','content','information','data','details','differences',
  // Domain-ish nouns (helpful when user omits "document")
  'expense','expenses','revenue','revenues','profit','profits','loss','losses','margin','margins',
  'budget','budgets','forecast','forecasts','ebitda','income','cost','costs','cash flow','assets',
  'liabilities','equity','roi','npv','irr',
  'clause','clauses','liability','termination','penalty','penalties','indemnity','warranty',
  'obligation','obligations','provision','provisions','terms','conditions','force majeure',
  'diagnosis','treatment','symptom','medication','prescription','dosage',
  'stakeholder','stakeholders','requirement','requirements','milestone','milestones','risk','risks',
  'deliverable','deliverables','timeline','scope','sprint','sprints',
]);

const CONTENT_NOUNS_PT = new Set([
  'tópicos','tópico','temas','tema','pontos','ponto','conclusões','conclusão','argumentos','argumento',
  'afirmações','afirmação','resumo','síntese','visão geral','essência','significado','destaques','destaque',
  'análise','conteúdo','informações','informação','dados','detalhes','diferenças',
  'despesa','despesas','receita','receitas','lucro','lucros','prejuízo','prejuízos','margem','margens',
  'orçamento','orçamentos','previsão','previsões','ebitda','custo','custos','fluxo de caixa','ativos','passivos',
  'cláusula','cláusulas','responsabilidade','rescisão','penalidade','penalidades','indenização','garantia',
  'obrigação','obrigações','disposição','disposições','termos','condições','força maior',
  'diagnóstico','diagnósticos','tratamento','tratamentos','sintoma','sintomas','medicação','medicações',
  'prescrição','prescrições','dosagem','dosagens',
  'requisito','requisitos','marco','marcos','risco','riscos','entregável','entregáveis','cronograma','escopo',
]);

const ANCHOR_NOUNS_EN = new Set([
  'page','pages','slide','slides','tab','tabs','sheet','sheets','cell','cells','section','sections','chapter',
  'chapters','paragraph','paragraphs','row','rows','column','columns','table','tables','figure','figures',
  'chart','charts','graph','graphs','appendix',
]);

const ANCHOR_NOUNS_PT = new Set([
  'página','páginas','slide','slides','aba','abas','planilha','planilhas','célula','células','seção','seções',
  'capítulo','capítulos','parágrafo','parágrafos','linha','linhas','coluna','colunas','tabela','tabelas',
  'figura','figuras','gráfico','gráficos','apêndice',
]);

const DOCUMENT_OBJECTS_EN = new Set([
  'document','documents','file','files','pdf','pdfs','presentation','presentations','spreadsheet','spreadsheets',
  'report','reports','contract','contracts','paper','papers','article','articles','deck','decks','workbook','workbooks',
  'memo','memos','letter','letters','proposal','proposals','agreement','agreements','invoice','invoices','statement','statements',
]);

const DOCUMENT_OBJECTS_PT = new Set([
  'documento','documentos','arquivo','arquivos','pdf','pdfs','apresentação','apresentações','planilha','planilhas',
  'relatório','relatórios','contrato','contratos','artigo','artigos','proposta','propostas','acordo','acordos','fatura','faturas','extrato','extratos',
]);

const FILE_ACTION_VERBS_EN = new Set([
  'open','show','list','display','view','preview','filter','sort','group','find','locate','search','look for',
  'move','delete','rename','copy','download','upload','share','archive','remove','create','navigate','go to','back to','pull up','bring up',
]);

const FILE_ACTION_VERBS_PT = new Set([
  'abrir','abra','mostrar','mostre','listar','liste','exibir','exiba','ver','veja','visualizar','visualize',
  'filtrar','filtre','ordenar','ordene','agrupar','agrupe','encontrar','encontre','localizar','localize',
  'procurar','procure','buscar','busque','mover','mova','deletar','delete','apagar','apague','renomear','renomeie',
  'copiar','copie','baixar','baixe','enviar','envie','compartilhar','compartilhe','arquivar','arquive','remover','remova',
  'criar','crie','navegar','navegue','ir para','vá para','voltar','puxar','puxe','trazer','traga',
]);

const FILE_NOUNS_EN = new Set([
  'files','file','documents','document','pdfs','pdf','folder','folders','directory','directories','spreadsheets','spreadsheet',
  'presentations','presentation','images','image','photos','photo','pictures','picture','uploads','upload','downloads','download',
  'attachments','attachment','excel','word','powerpoint','pptx','xlsx','docx','csv','txt','png','jpg',
]);

const FILE_NOUNS_PT = new Set([
  'arquivos','arquivo','documentos','documento','pdfs','pdf','pasta','pastas','diretório','diretórios','planilhas','planilha',
  'apresentações','apresentação','imagens','imagem','fotos','foto','uploads','upload','downloads','download','anexos','anexo',
  'excel','word','powerpoint','pptx','xlsx','docx','csv','txt',
]);

const STRONG_CONTENT_FRAMES_EN: RegExp[] = [
  /\bwhat\s+is\s+(?:the\s+)?(?:document|report|file)\s+about\b/i,
  /\bwhat\s+(?:topics?|themes?|points?)\s+does\s+.+?\s+(?:cover|discuss|mention|include)\b/i,
  /\bsummarize\s+(?:the|this)\b/i,
  /\bgive\s+me\s+(?:a\s+)?(?:summary|overview|synopsis)\b/i,
  /\bwhich\s+(?:page|slide|section|tab|sheet)\b.*\b(?:mentions?|shows?|contains?)\b/i,
  // "In [filename], where/what/how/which..." patterns (content about doc)
  /\bin\s+[^,]+?\.(?:pdf|docx?|xlsx?|pptx?|csv|txt|md)[,\s]+(?:where|what|how|which)\s+/i,
  /\bin\s+[^,]+?\.(?:pdf|docx?|xlsx?|pptx?|csv|txt|md),\s+(?:where|what|how|which)\b/i,
  // "From [filename], list/give/extract..." patterns (content extraction)
  /\bfrom\s+[^,]+?\.(?:pdf|docx?|xlsx?|pptx?|csv|txt|md)[,\s]+(?:give|extract|get|pull|show|list)\s+/i,
  /\bfrom\s+[^,]+?\.(?:pdf|docx?|xlsx?|pptx?|csv|txt|md),\s+(?:give|extract|get|pull|show|list)\b/i,
  // "where is X shown/mentioned" - asking about content location
  /\bwhere\s+is\s+\w+\s+(?:shown|mentioned|located|displayed|found)\b/i,
  // "list the first N items" - extraction
  /\blist\s+(?:the\s+)?(?:first|top|last)?\s*\d*\s*(?:items?|points?|findings?|things?|elements?)\s+(?:mentioned|in|from)\b/i,
  // Financial/compute queries (NOT doc_stats counts)
  /\bwhat\s+is\s+(?:the\s+)?(?:total|sum|average|mean)\s+(?:revenue|expense|cost|profit|income|sales|amount)\b/i,
  /\b(?:total|sum|average)\s+(?:revenue|expenses?|costs?|profits?|income|sales|amounts?)\b/i,
  // "show differences" = compare (content), not file action
  /\bshow\s+(?:the\s+)?differences?\s+(?:between|in|across)\b/i,
  /\bdifferences?\s+between\s+(?:the\s+)?(?:two|both|these)\b/i,
];

const STRONG_CONTENT_FRAMES_PT: RegExp[] = [
  /\bo\s+que\s+(?:o\s+)?(?:documento|relatório|arquivo)\s+fala\s+sobre\b/i,
  /\bdo\s+que\s+(?:se\s+)?trata\b/i,
  /\bquais?\s+(?:tópicos?|temas?|pontos?)\s+.+?\s+(?:cobre|aborda|discute|menciona)\b/i,
  /\b(?:resuma|resumir)\b/i,
  /\b(?:me\s+)?d[êe]\s+(?:um\s+)?(?:resumo|visão\s+geral)\b/i,
  /\b(?:em\s+)?qual\s+(?:página|slide|seção|aba|planilha)\b/i,
];

const STRONG_FILE_ACTION_FRAMES_EN: RegExp[] = [
  /^(?:show|list|display)\s+(?:all\s+)?(?:my\s+)?(?:files?|documents?|folders?)\b/i,
  /^(?:open|preview|view)\s+(?:the\s+)?(?:file|document|pdf|spreadsheet|presentation)\b/i,
  /\bshow\s+only\s+(?:pdfs?|images?|spreadsheets?|presentations?)\b/i,
  /\bhow\s+many\s+(?:files?|documents?)\b/i,
  /\bwhere\s+is\s+my\s+(?:file|document)\b/i,
  // "Where is [filename.ext]?" - asking for file location
  /\bwhere\s+is\s+[^?]+?\.(?:pdf|docx?|xlsx?|pptx?|csv|txt|md|png|jpg|jpeg)\s*\??\s*$/i,
];

const STRONG_FILE_ACTION_FRAMES_PT: RegExp[] = [
  /^(?:mostre|liste|exiba)\s+(?:todos?\s+)?(?:os\s+)?(?:meus?\s+)?(?:arquivos?|documentos?|pastas?)\b/i,
  /^(?:abra|abrir|visualizar|ver)\s+(?:o|a)?\s*(?:arquivo|documento|pdf|planilha|apresentação)\b/i,
  /\bmostrar\s+apenas\s+(?:pdfs?|imagens?|planilhas?|apresentações?)\b/i,
  /\bquantos?\s+(?:arquivos?|documentos?)\b/i,
  /\bonde\s+(?:está|fica)\s+(?:meu|minha)\s+(?:arquivo|documento)\b/i,
];

function countSignals(
  text: string,
  verbs: Set<string>,
  nouns: Set<string>,
  anchors: Set<string>,
  docObjects: Set<string>
): { verbCount: number; nounCount: number; anchorCount: number; docObjCount: number } {
  const normalized = text.toLowerCase();
  const folded = foldDiacritics(text);

  let verbCount = 0;
  let nounCount = 0;
  let anchorCount = 0;
  let docObjCount = 0;

  for (const v of verbs) {
    const vl = v.toLowerCase();
    const vf = foldDiacritics(v);
    if (normalized.includes(vl) || folded.includes(vf)) verbCount++;
  }
  for (const n of nouns) {
    const nl = n.toLowerCase();
    const nf = foldDiacritics(n);
    if (normalized.includes(nl) || folded.includes(nf)) nounCount++;
  }
  for (const a of anchors) {
    const al = a.toLowerCase();
    const af = foldDiacritics(a);
    if (normalized.includes(al) || folded.includes(af)) anchorCount++;
  }
  for (const d of docObjects) {
    const dl = d.toLowerCase();
    const df = foldDiacritics(d);
    if (normalized.includes(dl) || folded.includes(df)) docObjCount++;
  }

  return { verbCount, nounCount, anchorCount, docObjCount };
}

function twoSignalFallback(query: string, lang: LanguageCode): 'content' | 'file_action' | 'unknown' {
  const normalized = query.toLowerCase().trim();
  const folded = foldDiacritics(query).trim();

  // 1) Strong frames
  const contentFrames = lang === 'pt'
    ? [...STRONG_CONTENT_FRAMES_PT, ...STRONG_CONTENT_FRAMES_EN]
    : STRONG_CONTENT_FRAMES_EN;

  for (const re of contentFrames) {
    if (re.test(normalized) || re.test(folded)) return 'content';
  }

  const fileFrames = lang === 'pt'
    ? [...STRONG_FILE_ACTION_FRAMES_PT, ...STRONG_FILE_ACTION_FRAMES_EN]
    : STRONG_FILE_ACTION_FRAMES_EN;

  for (const re of fileFrames) {
    if (re.test(normalized) || re.test(folded)) return 'file_action';
  }

  // 2) Two-signal scoring
  const contentVerbs = lang === 'pt' ? new Set([...CONTENT_VERBS_EN, ...CONTENT_VERBS_PT]) : CONTENT_VERBS_EN;
  const contentNouns = lang === 'pt' ? new Set([...CONTENT_NOUNS_EN, ...CONTENT_NOUNS_PT]) : CONTENT_NOUNS_EN;
  const anchorNouns  = lang === 'pt' ? new Set([...ANCHOR_NOUNS_EN,  ...ANCHOR_NOUNS_PT])  : ANCHOR_NOUNS_EN;
  const docObjects   = lang === 'pt' ? new Set([...DOCUMENT_OBJECTS_EN, ...DOCUMENT_OBJECTS_PT]) : DOCUMENT_OBJECTS_EN;

  const fileVerbs = lang === 'pt' ? new Set([...FILE_ACTION_VERBS_EN, ...FILE_ACTION_VERBS_PT]) : FILE_ACTION_VERBS_EN;
  const fileNouns = lang === 'pt' ? new Set([...FILE_NOUNS_EN, ...FILE_NOUNS_PT]) : FILE_NOUNS_EN;

  const c = countSignals(query, contentVerbs, contentNouns, anchorNouns, docObjects);
  const f = countSignals(query, fileVerbs, fileNouns, new Set(), new Set());

  const hasContentIntent = c.verbCount > 0 || c.nounCount > 0;
  const hasContentObject = c.docObjCount > 0 || c.anchorCount > 0;

  // If user uses multiple content nouns (e.g., "EBITDA margin revenue"), treat as content
  const strongContentNounSignal = c.nounCount >= 2;

  const isContent = hasContentIntent && (hasContentObject || strongContentNounSignal);

  const isFileAction = f.verbCount > 0 && f.nounCount > 0;

  // Tie-break: content wins unless query clearly begins as a file navigation command
  if (isContent && isFileAction) {
    const startsFileVerb = /^(show|list|open|filter|sort|group|display|find|locate|mostre|liste|abra|filtre|ordene|agrupe|exiba|encontre|localize)\b/i;
    if (startsFileVerb.test(normalized)) {
      // If the query also includes anchors like page/slide/cell, prefer content.
      if (c.anchorCount > 0 || strongContentNounSignal) return 'content';
      return 'file_action';
    }
    return 'content';
  }

  if (isContent) return 'content';
  if (isFileAction) return 'file_action';
  return 'unknown';
}

// ─────────────────────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────────────────────

export interface ContentGuardResult {
  isContentQuestion: boolean;
  isFileAction: boolean;
  matchedPattern: string | null;
  matchedFamily: string | null;
  confidence: 'high' | 'medium' | 'low';
  recommendation: 'use_rag' | 'allow_file_action' | 'unknown';
  language: LanguageCode;
  debug?: {
    bankPatternsChecked: number;
    fallbackUsed: boolean;
  };
}

export function isContentQuestion(query: string, language?: LanguageCode): boolean {
  const q = query.trim();
  if (q.length < 3) return false;

  // File-organization is NEVER content.
  if (isFileOrganizationQuery(q)) return false;

  initializePatterns();
  const lang = language || detectLanguage(q);

  const negatives = lang === 'pt'
    ? [...(negativePatternsPT || []), ...(negativePatternsEN || [])]
    : (negativePatternsEN || []);

  if (matchesAny(q, negatives)) return false;

  const contents = lang === 'pt'
    ? [...(contentPatternsPT || []), ...(contentPatternsEN || [])]
    : (contentPatternsEN || []);

  if (matchesAny(q, contents)) return true;

  return twoSignalFallback(q, lang) === 'content';
}

export function isFileActionQuery(query: string, language?: LanguageCode): boolean {
  const q = query.trim();
  if (q.length < 3) return false;

  // File-organization is ALWAYS file_action.
  if (isFileOrganizationQuery(q)) return true;

  // Content wins.
  if (isContentQuestion(q, language)) return false;

  initializePatterns();
  const lang = language || detectLanguage(q);

  const negatives = lang === 'pt'
    ? [...(negativePatternsPT || []), ...(negativePatternsEN || [])]
    : (negativePatternsEN || []);

  if (matchesAny(q, negatives)) return true;

  return twoSignalFallback(q, lang) === 'file_action';
}

export function classifyQuery(query: string, language?: LanguageCode): ContentGuardResult {
  const q = query.trim();
  const lang = language || detectLanguage(q);

  // Fast exits
  if (isFileOrganizationQuery(q)) {
    return {
      isContentQuestion: false,
      isFileAction: true,
      matchedPattern: 'file_organization_query',
      matchedFamily: 'ORG',
      confidence: 'high',
      recommendation: 'allow_file_action',
      language: lang,
      debug: { bankPatternsChecked: 0, fallbackUsed: false },
    };
  }

  initializePatterns();

  const negatives = lang === 'pt'
    ? [...(negativePatternsPT || []), ...(negativePatternsEN || [])]
    : (negativePatternsEN || []);

  const contents = lang === 'pt'
    ? [...(contentPatternsPT || []), ...(contentPatternsEN || [])]
    : (contentPatternsEN || []);

  const norm = q.toLowerCase().trim();
  const folded = foldDiacritics(q).trim();

  // 1) Negative (file_action) matches
  for (let i = 0; i < negatives.length; i++) {
    const re = negatives[i];
    if (re.test(norm) || re.test(folded)) {
      return {
        isContentQuestion: false,
        isFileAction: true,
        matchedPattern: re.source.substring(0, 80),
        matchedFamily: `NG-${Math.floor(i / 40) + 1}`,
        confidence: 'high',
        recommendation: 'allow_file_action',
        language: lang,
        debug: { bankPatternsChecked: negatives.length, fallbackUsed: false },
      };
    }
  }

  // 2) Content matches
  for (let i = 0; i < contents.length; i++) {
    const re = contents[i];
    if (re.test(norm) || re.test(folded)) {
      return {
        isContentQuestion: true,
        isFileAction: false,
        matchedPattern: re.source.substring(0, 80),
        matchedFamily: `CG-${Math.floor(i / 80) + 1}`,
        confidence: 'high',
        recommendation: 'use_rag',
        language: lang,
        debug: { bankPatternsChecked: contents.length, fallbackUsed: false },
      };
    }
  }

  // 3) Fallback
  const fallback = twoSignalFallback(q, lang);
  if (fallback === 'content') {
    return {
      isContentQuestion: true,
      isFileAction: false,
      matchedPattern: 'two-signal-fallback',
      matchedFamily: 'FALLBACK',
      confidence: 'medium',
      recommendation: 'use_rag',
      language: lang,
      debug: { bankPatternsChecked: contents.length + negatives.length, fallbackUsed: true },
    };
  }
  if (fallback === 'file_action') {
    return {
      isContentQuestion: false,
      isFileAction: true,
      matchedPattern: 'two-signal-fallback',
      matchedFamily: 'FALLBACK',
      confidence: 'medium',
      recommendation: 'allow_file_action',
      language: lang,
      debug: { bankPatternsChecked: contents.length + negatives.length, fallbackUsed: true },
    };
  }

  return {
    isContentQuestion: false,
    isFileAction: false,
    matchedPattern: null,
    matchedFamily: null,
    confidence: 'low',
    recommendation: 'unknown',
    language: lang,
    debug: { bankPatternsChecked: contents.length + negatives.length, fallbackUsed: true },
  };
}

export function resetPatternCache(): void {
  contentPatternsEN = null;
  contentPatternsPT = null;
  negativePatternsEN = null;
  negativePatternsPT = null;
  bankLoadStatus = {
    enContentLoaded: 0,
    ptContentLoaded: 0,
    enNegativeLoaded: 0,
    ptNegativeLoaded: 0,
  };
}

export function getBankStats(): {
  enContent: number;
  ptContent: number;
  enNegative: number;
  ptNegative: number;
  fallbackContent: number;
  fallbackFileAction: number;
  bankLoadStatus: typeof bankLoadStatus;
} {
  initializePatterns();
  return {
    enContent: contentPatternsEN?.length || 0,
    ptContent: contentPatternsPT?.length || 0,
    enNegative: negativePatternsEN?.length || 0,
    ptNegative: negativePatternsPT?.length || 0,
    fallbackContent: STRONG_CONTENT_FRAMES_EN.length + STRONG_CONTENT_FRAMES_PT.length,
    fallbackFileAction: STRONG_FILE_ACTION_FRAMES_EN.length + STRONG_FILE_ACTION_FRAMES_PT.length,
    bankLoadStatus,
  };
}

// Expose internals for unit tests only
export const _testExports = {
  foldDiacritics,
  detectLanguage,
  twoSignalFallback,
  loadBankPatterns,
  STRONG_CONTENT_FRAMES_EN,
  STRONG_CONTENT_FRAMES_PT,
  STRONG_FILE_ACTION_FRAMES_EN,
  STRONG_FILE_ACTION_FRAMES_PT,
};
