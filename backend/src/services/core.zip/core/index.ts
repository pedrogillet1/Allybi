/**
 * Core Services Index V3
 * Re-exports all core RAG services
 */

// V3 Orchestrator (main entry point)
export * from './kodaOrchestratorV3.service';

// V3 Intent classification
export * from './kodaIntentEngineV3.service';

// V3 Config services (moved to src/services/config/ and src/services/data/)
export * from '../config/intentConfig.service';
export * from '../config/fallbackConfig.service';
export * from '../data/brainDataLoader.service';

// V3 Fallback engine ARCHIVED - fallback logic moved into orchestrator decision tree

// V3 Formatting pipeline ARCHIVED - AnswerComposer is the only formatter

// V3 Format constraint parser (bullet counts, tables, etc.)
// Note: FormatConstraints is also exported from completionGate.service and handlerResult.types
// Use explicit exports to avoid ambiguity
export {
  parseFormatConstraints,
  SupportedLanguage,
  FormatConstraints as ParsedFormatConstraints
} from './formatConstraintParser.service';

// V3 Product help (moved to src/services/help/)
export * from '../help/kodaProductHelpV3.service';

// V3 Pattern classifier ARCHIVED - pattern classification handled by runtimePatterns

// Retrieval and answer engines (unchanged)
export * from './kodaRetrievalEngineV3.service';
export * from './kodaAnswerEngineV3.service';

// Document resolution (moved to src/services/documents/)
export * from '../documents/documentResolution.service';

// Supporting services (unchanged)
export * from './languageDetector.service';
// multiIntent and override ARCHIVED - using inline stubs in orchestrator

// Math orchestrator (moved to src/services/math/)
export * from '../math/mathOrchestrator.service';

// Language enforcement (post-processing for PT/ES answers)
export * from './languageEnforcement.service';

// Evidence gate (anti-hallucination for doc Q&A)
export * from './evidenceGate.service';

// Scope gate (anti-contamination: single-doc vs multi-doc scoping)
export * from './scopeGate.service';

// Coherence gate (post-generation quality validation)
export * from './coherenceGate.service';

// Completion gate (pre-done validation: truncation, markers, constraints)
// Note: FormatConstraints is also exported from formatConstraintParser.service and handlerResult.types
// Use explicit exports to avoid ambiguity
export {
  CompletionGateService,
  getCompletionGateService,
  CompletionValidation,
  CompletionIssue,
  FormatConstraints as GateFormatConstraints,
  RepairAction,
  DoneEventPayload
} from './completionGate.service';

// Month normalization (expands "July" to match "Jul-2024" in spreadsheets)
// MOVED to services/utils/
export * from '../utils/monthNormalization.service';

// Answer Composer (CENTRALIZED output formatting - ALL responses must pass through)
export * from './answerComposer.service';

// Source Buttons (CENTRALIZED source/citation handling - ChatGPT-like pills)
export * from './sourceButtons.service';

// Operator Resolver (ChatGPT-like operator detection with policy integration)
// Note: ActionType and OperatorMatch are also exported from other services
// Use explicit exports to avoid ambiguity
export {
  OperatorResolver,
  OperatorResolverWithPolicy,
  getOperatorResolver,
  getOperatorResolverWithPolicy,
  OperatorType,
  OperatorMatch as ResolverOperatorMatch,
  OperatorResult,
  ActionType as ResolverActionType,
  ActionResult
} from './operatorResolver.service';

// Template Governance (operator-to-template rules, format constraints)
export * from './templateGovernance.service';

// Presentation Normalizer (bullets, numbered lists, tables, paragraphs)
// MOVED to services/presentations/
export * from '../presentations/presentationNormalizer.service';

// Follow-up Suppression (strict rules for when follow-ups should NEVER appear)
// Note: ActionType is also exported from operatorResolver.service
// Use explicit exports to avoid ambiguity
export {
  FollowupSuppressionService,
  getFollowupSuppressor,
  FollowupType,
  DocScope,
  ResponseType,
  ErrorType,
  ActionType as FollowupActionType,
  SuppressionContext,
  FollowupSuggestion,
  SuppressionResult
} from './followupSuppression.service';

// Capability Registry (validates follow-ups only suggest available actions)
export * from './capabilityRegistry.service';

// Clarify Templates (short, contextual clarification messages)
export * from './clarifyTemplates.service';

// Boilerplate Stripper (removes "Key points:", "Here's what I found:", etc.)
export * from './boilerplateStripper.service';

// Trust Gate (ensures no fact invention, states plainly when evidence missing)
export * from './trustGate.service';

// Terminology Service (moved to src/services/data/)
export * from '../data/terminology.service';

// Document Intelligence Services (moved to src/services/documents/)
export * from '../documents/findMentions.service';
export * from '../documents/documentOutline.service';
export * from '../documents/documentCompare.service';

// Runtime Patterns (CENTRALIZED pattern matching - replaces hardcoded patterns)
// Note: OperatorMatch is also exported from operatorResolver.service
// Use explicit exports to avoid ambiguity
export {
  RuntimePatternsService,
  runtimePatterns,
  PatternMatch,
  OperatorMatch as RuntimeOperatorMatch,
  IntentMatch,
  FormatConstraint as RuntimeFormatConstraint,
  // Re-exports from dataBankLoader
  loadPatternBank,
  matchesKeywords,
  matchesKeywordsForLang,
  extractExtensions,
  getAllFileTypeWords,
  isFileOrganizationQuery,
  detectInventoryType,
  detectOperatorFromQuery,
  getLanguageIndicators,
  getDomainKeywords,
  dataBankLoader
} from './runtimePatterns.service';
export type {
  MasterPatternBank,
  PatternFamily,
  PatternBank,
  LoadedBank
} from './runtimePatterns.service';
