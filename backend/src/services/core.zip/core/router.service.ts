/**
 * Router Service - Single Source of Truth for Query Routing
 *
 * This is the ONLY place routing decisions are made.
 * Orchestrator calls router.route() and trusts the result completely.
 * No second-guessing, no overrides, no regex checks after this.
 *
 * ChatGPT-style: one brain, one decision, one output.
 *
 * BANK-DRIVEN: All patterns come from JSON data banks via runtimePatterns.
 * NO hardcoded regex in this file - use bank services instead.
 */

import { runtimePatterns } from './runtimePatterns.service';
import { DefaultLanguageDetector, ILanguageDetector, LanguageResult } from './languageDetector.service';
import { classifyQuery, ContentGuardResult } from './contentGuard.service';
import { getScopeGate, ScopeDecision } from './scopeGate.service';
import { getClarifyTemplates, ClarifyTemplatesService } from './clarifyTemplates.service';
import { normalizeQuery, NormalizedQuery } from './queryNormalizer.service';

// ═══════════════════════════════════════════════════════════════════════════
// ROUTING RESULT TYPE - The single contract between Router and Orchestrator
// ═══════════════════════════════════════════════════════════════════════════

export type IntentFamily = 'documents' | 'file_actions' | 'help' | 'conversation' | 'reasoning' | 'doc_stats' | 'error';

export type Operator =
  | 'list' | 'filter' | 'sort' | 'group' | 'open' | 'locate_file' | 'again' | 'count'  // file_actions operators
  | 'locate_content' | 'summarize' | 'extract' | 'compare' | 'compute' | 'explain' | 'expand'  // documents operators
  | 'count_pages' | 'count_sheets' | 'count_slides'  // doc_stats operators
  | 'capabilities' | 'how_to'  // help operators
  | 'unknown';

export type DocScopeMode = 'none' | 'single_doc' | 'multi_doc' | 'workspace';

export interface DocScope {
  mode: DocScopeMode;
  docIds?: string[];
  docNames?: string[];
  folderPath?: string;
}

export interface RoutingFlags {
  isFollowup: boolean;
  hasPronoun: boolean;
  hasExplicitFilename: boolean;
  isInventoryQuery: boolean;
  isContentQuestion: boolean;
  requiresRAG: boolean;
  lowConfidence: boolean;
}

export interface RoutingResult {
  languageLocked: 'en' | 'pt' | 'es';
  intentFamily: IntentFamily;
  operator: Operator;
  subIntent?: string;
  docScope: DocScope;
  confidence: number;
  shouldClarify: boolean;
  clarifyQuestion?: string;
  matchedPatternIds?: string[];
  flags: RoutingFlags;
  // Debug/telemetry
  _debug?: {
    rawIntentScores?: Array<{ intent: string; score: number }>;
    operatorMatches?: Array<{ operator: string; confidence: number }>;
    appliedRules?: string[];
    languageDetection?: LanguageResult;
    contentGuard?: ContentGuardResult;
    scopeDecision?: ScopeDecision;
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// ROUTING REQUEST
// ═══════════════════════════════════════════════════════════════════════════

export interface RoutingRequest {
  text: string;
  userId: string;
  conversationId?: string;
  language?: string;
  hasDocuments: boolean;
  recentDocIds?: string[];
  recentDocNames?: string[];
  previousIntent?: string;
  previousOperator?: string;
  availableDocs?: Array<{ id: string; filename: string; mimeType?: string; createdAt?: Date }>;
}

// ═══════════════════════════════════════════════════════════════════════════
// CONFIDENCE THRESHOLDS (ChatGPT-like)
// ═══════════════════════════════════════════════════════════════════════════

const CONFIDENCE_THRESHOLDS = {
  LOW_CONFIDENCE: 0.5,      // Below this = lowConfidence flag true
  CLARIFY_THRESHOLD: 0.4,   // Below this = consider clarification (but rare)
  HIGH_CONFIDENCE: 0.8,     // Above this = very confident, never clarify
};

// ═══════════════════════════════════════════════════════════════════════════
// ROUTER SERVICE
// ═══════════════════════════════════════════════════════════════════════════

export class RouterService {
  private static instance: RouterService;
  private languageDetector: ILanguageDetector;
  private scopeGate = getScopeGate();
  private clarifyTemplates: ClarifyTemplatesService;

  private constructor() {
    this.languageDetector = new DefaultLanguageDetector();
    this.clarifyTemplates = getClarifyTemplates();
  }

  static getInstance(): RouterService {
    if (!RouterService.instance) {
      RouterService.instance = new RouterService();
    }
    return RouterService.instance;
  }

  /**
   * Main routing method - THE ONLY place routing decisions are made
   *
   * Orchestrator must trust this result completely.
   * No overrides, no second-guessing, no regex checks after this.
   */
  async route(request: RoutingRequest): Promise<RoutingResult> {
    const appliedRules: string[] = [];

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 0: Query Normalization - Apply typo corrections for robustness
    // ChatGPT-like: understand what user meant, not just what they typed
    // ═══════════════════════════════════════════════════════════════════════
    const normalized = normalizeQuery(request.text, true);
    const query = normalized.normalized; // Use normalized text for all matching

    if (normalized.corrections.length > 0) {
      appliedRules.push(`typo_corrections:${normalized.corrections.map(c => `${c.original}->${c.corrected}`).join(',')}`);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 1: Language Detection - Use languageDetector FIRST, not request.language
    // ChatGPT-like: detect from query content, don't trust client hints blindly
    // ═══════════════════════════════════════════════════════════════════════
    const languageResult = await this.languageDetector.detectWithConfidence(query);
    let languageLocked: 'en' | 'pt' | 'es';

    if (languageResult.lang !== 'unknown' && languageResult.confidence >= 0.3) {
      // Trust detected language from query content
      languageLocked = languageResult.lang as 'en' | 'pt' | 'es';
      appliedRules.push(`lang:detected:${languageLocked}:${languageResult.confidence.toFixed(2)}`);
    } else if (request.language) {
      // Fall back to request.language only if detection is uncertain
      const normalized = request.language.toLowerCase();
      if (normalized.startsWith('pt')) languageLocked = 'pt';
      else if (normalized.startsWith('es')) languageLocked = 'es';
      else languageLocked = 'en';
      appliedRules.push(`lang:request_fallback:${languageLocked}`);
    } else {
      // Default to English
      languageLocked = 'en';
      appliedRules.push('lang:default:en');
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 2: Get operator matches from runtime patterns (BANK-DRIVEN)
    // All patterns come from compiled JSON, no hardcoded regex
    // ═══════════════════════════════════════════════════════════════════════
    const operatorMatches = runtimePatterns.getOperatorMatches(query, languageLocked);
    const intentMatches = runtimePatterns.getIntentMatches(query, languageLocked);

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 3: Detect routing flags using BANK-DRIVEN methods only
    // NO hardcoded regex - use runtimePatterns and contentGuard services
    // ═══════════════════════════════════════════════════════════════════════
    const contentGuardResult = classifyQuery(query, languageLocked);
    const flags = this.detectFlags(query, languageLocked, request, contentGuardResult);

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 4: Determine intent family and operator using priority rules
    // ═══════════════════════════════════════════════════════════════════════
    let { intentFamily, operator, confidence, subIntent } = this.resolveIntentAndOperator(
      query,
      languageLocked,
      operatorMatches,
      intentMatches,
      flags,
      request,
      contentGuardResult,
      appliedRules
    );

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 4.5: "again" operator inheritance - ChatGPT-style repeat
    // If operator is "again" and we have previousOperator, inherit it
    // ═══════════════════════════════════════════════════════════════════════
    if (operator === 'again' && request.previousOperator) {
      operator = request.previousOperator as Operator;
      if (request.previousIntent) {
        intentFamily = request.previousIntent as IntentFamily;
      }
      appliedRules.push(`rule:again_inherits_${request.previousOperator}`);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 5: Set requiresRAG and lowConfidence flags PROPERLY
    // ═══════════════════════════════════════════════════════════════════════
    flags.requiresRAG = this.determineRequiresRAG(intentFamily, operator, request.hasDocuments);
    flags.lowConfidence = confidence < CONFIDENCE_THRESHOLDS.LOW_CONFIDENCE;

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 6: Determine document scope using BANK-DRIVEN scopeGate
    // ═══════════════════════════════════════════════════════════════════════
    const scopeDecision = this.scopeGate.detectScope(
      query,
      request.availableDocs || [],
      languageLocked,
      {
        lastDocIds: request.recentDocIds,
        lastDocNames: request.recentDocNames,
      }
    );

    let docScope = this.convertScopeDecision(scopeDecision, intentFamily, query);

    // ═══════════════════════════════════════════════════════════════════════
    // SCOPE OVERRIDE: Compare queries with multi-doc signals → multi_doc
    // Patterns like "compare the two", "2024 vs 2025", "both files" etc.
    // ═══════════════════════════════════════════════════════════════════════
    if (operator === 'compare') {
      const multiDocSignals = /\b(the\s+two|both|versus|vs\.?|two\s+(files?|documents?|p&l)|2024\s+(vs\.?|versus)\s+2025|comparing\s+(two|both|multiple))\b/i;
      if (multiDocSignals.test(query)) {
        docScope = { mode: 'multi_doc' };
        appliedRules.push('rule:compare_multi_doc_signal');
      }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SCOPE OVERRIDE: Generic format/style requests with no doc reference → workspace
    // Queries like "Give me the answer in numbered steps" should search all docs
    // ═══════════════════════════════════════════════════════════════════════
    const hasDocReference = /\.(pdf|docx?|xlsx?|pptx?|csv|txt)\b/i.test(query) ||
                           /\b(the\s+document|this\s+file|it|that)\b/i.test(query);
    const isFormatRequest = /\b(in\s+(numbered|bullet|table|list)\s*(points?|steps?|format)?|exactly\s+\d+\s+bullets?|as\s+a\s+table)\b/i.test(query);
    if (!hasDocReference && isFormatRequest && docScope.mode === 'single_doc' && !flags.isFollowup) {
      docScope = { mode: 'workspace' };
      appliedRules.push('rule:format_request_workspace');
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 6.5: FOLLOW-UP INHERITANCE - ChatGPT-like behavior
    // Follow-ups stay on the same document(s) unless user clearly switches
    // Only applies to document queries (not file_actions which use mode='none')
    // ═══════════════════════════════════════════════════════════════════════
    if (flags.isFollowup && intentFamily === 'documents' && request.recentDocIds && request.recentDocIds.length > 0) {
      // Inherit doc scope from previous turn
      if (request.recentDocIds.length === 1) {
        docScope = {
          mode: 'single_doc',
          docIds: request.recentDocIds,
          docNames: request.recentDocNames,
        };
      } else {
        docScope = {
          mode: 'multi_doc',
          docIds: request.recentDocIds,
          docNames: request.recentDocNames,
        };
      }
      appliedRules.push('rule:followup_inherit_scope');

      // ALSO inherit operator for ambiguous follow-ups like "Now do August"
      // If no strong operator signal, try to infer from context
      const hasStrongOperatorSignal = operatorMatches.length > 0 && operatorMatches[0].confidence >= 0.7;
      if (!hasStrongOperatorSignal) {
        if (request.previousOperator) {
          operator = request.previousOperator as Operator;
          appliedRules.push(`rule:followup_inherit_operator:${request.previousOperator}`);
        } else if (request.recentDocIds && request.recentDocIds.length >= 2) {
          // 2+ docs in context likely means comparison was happening
          operator = 'compare';
          appliedRules.push('rule:followup_infer_compare');
        }
      }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STEP 7: Check if clarification needed - ChatGPT-like: RARE clarification
    // Only clarify when truly ambiguous, prefer making best guess
    // ═══════════════════════════════════════════════════════════════════════
    const { shouldClarify, clarifyQuestion } = this.checkClarification(
      query,
      intentFamily,
      operator,
      confidence,
      flags,
      request,
      scopeDecision,
      languageLocked
    );

    // ═══════════════════════════════════════════════════════════════════════
    // BUILD FINAL RESULT
    // ═══════════════════════════════════════════════════════════════════════
    const result: RoutingResult = {
      languageLocked,
      intentFamily,
      operator,
      subIntent,
      docScope,
      confidence,
      shouldClarify,
      clarifyQuestion,
      matchedPatternIds: operatorMatches.flatMap(m => m.matchedPatterns || []),
      flags,
      _debug: {
        rawIntentScores: intentMatches.map(m => ({ intent: m.intent, score: m.confidence })),
        operatorMatches: operatorMatches.map(m => ({ operator: m.operator, confidence: m.confidence })),
        appliedRules,
        languageDetection: languageResult,
        contentGuard: contentGuardResult,
        scopeDecision,
      },
    };

    console.log(`[Router] ${query.substring(0, 40)}... → ${intentFamily}/${operator} (${(confidence * 100).toFixed(0)}%) lang=${languageLocked} requiresRAG=${flags.requiresRAG}`);

    return result;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PRIVATE METHODS - All using BANK-DRIVEN services, NO hardcoded regex
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Detect flags using BANK-DRIVEN methods only
   * NO hardcoded regex - uses runtimePatterns and contentGuard
   */
  private detectFlags(
    query: string,
    lang: string,
    request: RoutingRequest,
    contentGuardResult: ContentGuardResult
  ): RoutingFlags {
    return {
      // BANK-DRIVEN: Use runtimePatterns.isFollowupQuery
      isFollowup: runtimePatterns.isFollowupQuery(query, lang),

      // BANK-DRIVEN: Use runtimePatterns.hasPronounReference
      hasPronoun: runtimePatterns.hasPronounReference(query, lang),

      // BANK-DRIVEN: Use runtimePatterns.hasExplicitFilename
      hasExplicitFilename: runtimePatterns.hasExplicitFilename(query, lang),

      // BANK-DRIVEN: Use runtimePatterns.isInventoryQuery
      isInventoryQuery: runtimePatterns.isInventoryQuery(query, lang),

      // BANK-DRIVEN: Use contentGuard.classifyQuery result
      isContentQuestion: contentGuardResult.isContentQuestion,

      // Set properly in STEP 5 after intentFamily is determined
      requiresRAG: false,
      lowConfidence: false,
    };
  }

  /**
   * Determine if RAG is required based on intent and operator
   */
  private determineRequiresRAG(
    intentFamily: IntentFamily,
    operator: Operator,
    hasDocuments: boolean
  ): boolean {
    // file_actions don't need RAG (database lookup)
    if (intentFamily === 'file_actions') {
      return false;
    }

    // help and conversation don't need RAG
    if (intentFamily === 'help' || intentFamily === 'conversation') {
      return false;
    }

    // doc_stats might need RAG for content analysis
    if (intentFamily === 'doc_stats') {
      return hasDocuments;
    }

    // documents intent requires RAG if user has documents
    if (intentFamily === 'documents') {
      return hasDocuments;
    }

    // reasoning might need RAG
    if (intentFamily === 'reasoning') {
      return hasDocuments;
    }

    return false;
  }

  /**
   * Resolve intent family and operator using priority rules
   * Uses BANK-DRIVEN operator matches sorted by confidence
   */
  private resolveIntentAndOperator(
    query: string,
    lang: string,
    operatorMatches: Array<{ operator: string; confidence: number; matchedPatterns: string[] }>,
    intentMatches: Array<{ intent: string; confidence: number }>,
    flags: RoutingFlags,
    request: RoutingRequest,
    contentGuardResult: ContentGuardResult,
    appliedRules: string[]
  ): { intentFamily: IntentFamily; operator: Operator; confidence: number; subIntent?: string } {

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 0: Doc stats queries (how many pages/slides/sheets)
    // BANK-DRIVEN: Uses runtimePatterns.isDocStatsQuery
    // Must check BEFORE content questions since these are specific doc queries
    // ═══════════════════════════════════════════════════════════════════════
    const docStatsResult = runtimePatterns.isDocStatsQuery(query, lang);
    if (docStatsResult.isDocStats && request.hasDocuments) {
      appliedRules.push(`rule:doc_stats:${docStatsResult.statsType}`);

      // Map stats type to operator (bank-driven detection already done)
      const statsOperatorMap: Record<string, Operator> = {
        pages: 'count_pages',
        slides: 'count_slides',
        sheets: 'count_sheets',
        words: 'count_pages',
        size: 'count_pages',
      };

      return {
        intentFamily: 'doc_stats',
        operator: statsOperatorMap[docStatsResult.statsType || 'pages'] || 'count_pages',
        confidence: 0.90,
        subIntent: docStatsResult.statsType,
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 0.4: File location queries ("where is it located", "it located")
    // The word "located" strongly implies FILE location, not content location
    // ═══════════════════════════════════════════════════════════════════════
    const fileLocationPattern = /\b(where is it located|it located|is it located|file located|document located)\b/i;
    if (fileLocationPattern.test(query)) {
      appliedRules.push('rule:file_location');
      return {
        intentFamily: 'file_actions',
        operator: 'locate_file',
        confidence: 0.90,
        subIntent: 'locate_file',
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 0.5: Content discovery queries (which file is about X)
    // These look like file_actions but are actually content searches
    // ═══════════════════════════════════════════════════════════════════════
    if (this.isContentDiscoveryQuery(query) && request.hasDocuments) {
      appliedRules.push('rule:content_discovery');

      // Check if this is a "what is it about" query → summarize
      const aboutPattern = /\bwhat.+about\b|\bdo que.+(trata|sobre)\b|\bsobre o que\b/i;
      if (aboutPattern.test(query)) {
        return {
          intentFamily: 'documents',
          operator: 'summarize',
          confidence: 0.85,
          subIntent: 'content_about',
        };
      }

      return {
        intentFamily: 'documents',
        operator: 'extract',
        confidence: 0.85,
        subIntent: 'content_discovery',
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 1: ContentGuard says content question + has documents → documents
    // This ALWAYS wins - contentGuard is the authority on content vs file questions
    // ═══════════════════════════════════════════════════════════════════════
    if (contentGuardResult.isContentQuestion && request.hasDocuments) {
      appliedRules.push('rule:contentGuard_to_documents');

      // Find the best document operator from bank-driven matches
      const docOperators = ['summarize', 'extract', 'compare', 'compute', 'explain', 'locate_content'];
      const docMatches = operatorMatches.filter(m => docOperators.includes(m.operator));

      // SPECIAL CASE: "what is...about" queries should prefer summarize over extract
      // This handles queries like "what is the document about?" which extract might steal
      const aboutPattern = /\bwhat.+about\b|\babout\s+(what|the\s+document)\b|\bdo que.+(trata|sobre)\b|\bsobre o que\b/i;
      if (aboutPattern.test(query)) {
        const summarizeMatch = docMatches.find(m => m.operator === 'summarize');
        console.log(`[Router] aboutPattern matched, summarizeMatch:`, summarizeMatch, 'docMatches:', docMatches.map(m => m.operator));
        if (summarizeMatch) {
          appliedRules.push('rule:about_prefers_summarize');
          return {
            intentFamily: 'documents',
            operator: 'summarize',
            confidence: Math.max(summarizeMatch.confidence, 0.80),
            subIntent: 'summarize',
          };
        }
        // If summarize not in matches but aboutPattern matched, force summarize anyway
        appliedRules.push('rule:about_forces_summarize');
        return {
          intentFamily: 'documents',
          operator: 'summarize',
          confidence: 0.80,
          subIntent: 'summarize',
        };
      }

      const docMatch = docMatches[0];

      return {
        intentFamily: 'documents',
        operator: (docMatch?.operator as Operator) || 'extract',
        confidence: Math.max(docMatch?.confidence || 0.75, contentGuardResult.confidence === 'high' ? 0.85 : 0.70),
        subIntent: docMatch?.operator,
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 2: Inventory query (no content) → file_actions
    // BANK-DRIVEN: Uses runtimePatterns.isInventoryQuery + operator matches
    // ═══════════════════════════════════════════════════════════════════════
    if (flags.isInventoryQuery && !flags.isContentQuestion) {
      appliedRules.push('rule:inventory_to_file_actions');

      // Find the best file action operator from bank-driven matches
      const fileActionOps = ['list', 'filter', 'sort', 'group', 'count', 'open', 'locate_file'];
      const fileMatch = operatorMatches.find(m => fileActionOps.includes(m.operator));

      return {
        intentFamily: 'file_actions',
        operator: (fileMatch?.operator as Operator) || 'list',
        confidence: Math.max(fileMatch?.confidence || 0.85, 0.85),
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 3: ContentGuard says file action → file_actions
    // ═══════════════════════════════════════════════════════════════════════
    if (contentGuardResult.isFileAction) {
      appliedRules.push('rule:contentGuard_to_file_actions');

      // Find the best file action operator from bank-driven matches
      const fileActionOps = ['list', 'filter', 'sort', 'group', 'open', 'locate_file', 'again', 'count'];
      const fileMatches = operatorMatches.filter(m => fileActionOps.includes(m.operator));

      // Special case: "again" takes priority when there's context (recentDocIds)
      // This handles queries like "Open it again" where both "open" and "again" match
      const hasRepeatContext = !!(request.previousOperator || (request.recentDocIds && request.recentDocIds.length > 0));
      const againMatch = fileMatches.find(m => m.operator === 'again');
      if (hasRepeatContext && againMatch) {
        appliedRules.push('rule:again_with_context');
        return {
          intentFamily: 'file_actions',
          operator: 'again',
          confidence: Math.max(againMatch.confidence, 0.90),
          subIntent: 'again',
        };
      }

      const fileMatch = fileMatches[0]; // First match by confidence

      return {
        intentFamily: 'file_actions',
        operator: (fileMatch?.operator as Operator) || 'list',
        confidence: Math.max(fileMatch?.confidence || 0.75, contentGuardResult.confidence === 'high' ? 0.85 : 0.70),
        subIntent: fileMatch?.operator,
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 4: Bank-driven operator detection (highest confidence wins)
    // operatorMatches are already sorted by confidence (descending)
    // ═══════════════════════════════════════════════════════════════════════

    if (operatorMatches.length > 0) {
      // CONTEXTUAL FILTER: "again" operator only triggers with context
      // Context signals: previousOperator or recentDocIds (from prior actions in session)
      // This prevents "What are the rules again?" from being misrouted as a repeat action
      const hasRepeatContext = !!(
        request.previousOperator ||
        (request.recentDocIds && request.recentDocIds.length > 0)
      );

      let filteredMatches = operatorMatches;
      if (!hasRepeatContext) {
        filteredMatches = operatorMatches.filter(m => m.operator !== 'again');
      }

      if (filteredMatches.length === 0) {
        // All matches were "again" without context - fall through to other detection
        appliedRules.push('rule:again_filtered_no_context');
        // Continue to PRIORITY 5 below
      } else {
        const topMatch = filteredMatches[0];
        const { intentFamily, operator } = this.operatorToIntent(topMatch.operator);

        // Special handling: locate operators - use BANK-DRIVEN detection
        if (topMatch.operator === 'locate' || topMatch.operator === 'locate_file' || topMatch.operator === 'locate_content') {
          // BANK-DRIVEN: Use runtimePatterns.isLocationQuery for file location
          const isFileLocation = runtimePatterns.isLocationQuery(query, lang) && !flags.isContentQuestion;

          if (isFileLocation) {
            appliedRules.push('rule:locate_file');
            return {
              intentFamily: 'file_actions',
              operator: 'locate_file',
              confidence: topMatch.confidence,
            };
          } else {
            appliedRules.push('rule:locate_content');
            return {
              intentFamily: 'documents',
              operator: 'locate_content',
              confidence: topMatch.confidence,
            };
          }
        }

        appliedRules.push(`rule:operator_match:${topMatch.operator}`);
        return {
          intentFamily,
          operator: operator as Operator,
          confidence: topMatch.confidence,
          subIntent: topMatch.operator,
        };
      }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 5: Intent-based fallback
    // intentMatches are already sorted by confidence (descending)
    // ═══════════════════════════════════════════════════════════════════════
    if (intentMatches.length > 0) {
      const topIntent = intentMatches[0];
      const family = this.intentToFamily(topIntent.intent);
      const defaultOp = this.getDefaultOperator(family);

      appliedRules.push(`rule:intent_fallback:${topIntent.intent}`);
      return {
        intentFamily: family,
        operator: defaultOp,
        confidence: topIntent.confidence,
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 6: Has documents → documents/extract (default)
    // ChatGPT-like: make a best guess rather than asking
    // ═══════════════════════════════════════════════════════════════════════
    if (request.hasDocuments) {
      appliedRules.push('rule:default_documents');
      return {
        intentFamily: 'documents',
        operator: 'extract',
        confidence: 0.50,
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PRIORITY 7: No documents → help
    // ═══════════════════════════════════════════════════════════════════════
    appliedRules.push('rule:default_help');
    return {
      intentFamily: 'help',
      operator: 'capabilities',
      confidence: 0.40,
    };
  }

  /**
   * Check if query is a document discovery question (which document/file mentions X)
   * These should ALWAYS use workspace scope to search all documents
   */
  private isDocumentDiscoveryQuery(query: string): boolean {
    const discoveryPatterns = [
      /\bwhich\s+(document|file|pdf|report|spreadsheet|presentation)\b/i,
      /\bqual\s+(documento|arquivo|pdf|relatório|planilha|apresentação)\b/i,
      /\bwhat\s+(document|file|pdf|report)\s+(mentions?|contains?|has|shows?|talks?\s+about|is\s+about)/i,
      /\bque\s+(documento|arquivo)\s+(menciona|contém|tem|mostra|fala|é\s+sobre)/i,
      // "Which file is about X" pattern
      /\bwhich\s+(document|file)\s+is\s+about\b/i,
      /\bqual\s+(documento|arquivo)\s+(é|está)\s+sobre\b/i,
    ];
    return discoveryPatterns.some(p => p.test(query));
  }

  /**
   * Check if query is asking about content across documents (not file management)
   * These are content questions that need RAG, not file_actions
   */
  private isContentDiscoveryQuery(query: string): boolean {
    const contentPatterns = [
      /\bwhich\s+(file|document)\s+is\s+about\b/i,
      /\bqual\s+(arquivo|documento)\s+(?:é|trata)\s+(?:sobre|de)\b/i,
      /\bwhat\s+(?:file|document)\s+talks?\s+about\b/i,
      /\b(?:file|document)\s+(?:about|regarding|related\s+to)\b/i,
    ];
    return contentPatterns.some(p => p.test(query));
  }

  /**
   * Convert scopeGate decision to DocScope
   */
  private convertScopeDecision(scopeDecision: ScopeDecision, intentFamily: IntentFamily, query?: string): DocScope {
    // file_actions don't use RAG scope
    if (intentFamily === 'file_actions') {
      return { mode: 'none' };
    }

    // DOCUMENT DISCOVERY OVERRIDE: "which document/file..." queries should always search workspace
    // These are asking WHICH document (searching across all), not about a specific document
    if (query && this.isDocumentDiscoveryQuery(query)) {
      return { mode: 'workspace' };
    }

    switch (scopeDecision.type) {
      case 'single_doc':
        return {
          mode: 'single_doc',
          docIds: scopeDecision.targetDocIds,
          docNames: scopeDecision.targetDocNames,
        };
      case 'multi_doc':
        return {
          mode: 'multi_doc',
          docIds: scopeDecision.targetDocIds,
          docNames: scopeDecision.targetDocNames,
        };
      case 'any_doc':
        return { mode: 'workspace' };
      case 'needs_clarification':
        // Even when scope needs clarification, default to workspace search
        // ChatGPT-like: prefer making a guess over asking user
        return { mode: 'workspace' };
      default:
        return { mode: 'workspace' };
    }
  }

  private operatorToIntent(operator: string): { intentFamily: IntentFamily; operator: string } {
    const fileActionsOps = ['list', 'filter', 'sort', 'group', 'open', 'locate_file', 'again', 'count'];
    const documentsOps = ['summarize', 'extract', 'compare', 'compute', 'explain', 'locate_content', 'expand'];
    const docStatsOps = ['count_pages', 'count_sheets', 'count_slides'];
    const helpOps = ['capabilities', 'how_to', 'help'];

    if (fileActionsOps.includes(operator)) {
      return { intentFamily: 'file_actions', operator };
    }
    if (documentsOps.includes(operator)) {
      return { intentFamily: 'documents', operator };
    }
    if (docStatsOps.includes(operator)) {
      return { intentFamily: 'doc_stats', operator };
    }
    if (helpOps.includes(operator)) {
      return { intentFamily: 'help', operator };
    }

    return { intentFamily: 'documents', operator: 'extract' };
  }

  private intentToFamily(intent: string): IntentFamily {
    const mapping: Record<string, IntentFamily> = {
      documents: 'documents',
      file_actions: 'file_actions',
      help: 'help',
      conversation: 'conversation',
      reasoning: 'reasoning',
      doc_stats: 'doc_stats',
      accounting: 'documents',
      finance: 'documents',
      legal: 'documents',
      medical: 'documents',
      engineering: 'documents',
      error: 'error',
    };
    return mapping[intent] || 'documents';
  }

  private getDefaultOperator(family: IntentFamily): Operator {
    const defaults: Record<IntentFamily, Operator> = {
      documents: 'extract',
      file_actions: 'list',
      help: 'capabilities',
      conversation: 'unknown',
      reasoning: 'compute',
      doc_stats: 'count_pages',
      error: 'unknown',
    };
    return defaults[family];
  }

  /**
   * Check if clarification is needed - ChatGPT-like: RARE clarification
   * Prefer making best guess over asking user
   *
   * Uses BANK-DRIVEN clarifyTemplates for messages when needed
   */
  private checkClarification(
    query: string,
    intentFamily: IntentFamily,
    operator: Operator,
    confidence: number,
    flags: RoutingFlags,
    request: RoutingRequest,
    scopeDecision: ScopeDecision,
    language: 'en' | 'pt' | 'es'
  ): { shouldClarify: boolean; clarifyQuestion?: string } {

    // ═══════════════════════════════════════════════════════════════════════
    // ChatGPT-like: NEVER clarify for high confidence queries
    // ═══════════════════════════════════════════════════════════════════════
    if (confidence >= CONFIDENCE_THRESHOLDS.HIGH_CONFIDENCE) {
      return { shouldClarify: false };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ChatGPT-like: NEVER clarify for inventory or content questions
    // These have clear intent even at lower confidence
    // ═══════════════════════════════════════════════════════════════════════
    if (flags.isInventoryQuery || flags.isContentQuestion) {
      return { shouldClarify: false };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ChatGPT-like: Don't clarify for help intent
    // ═══════════════════════════════════════════════════════════════════════
    if (intentFamily === 'help') {
      return { shouldClarify: false };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ONLY clarify for pronoun reference WITHOUT context (truly ambiguous)
    // But still prefer not to clarify if we have any documents
    // ═══════════════════════════════════════════════════════════════════════
    if (
      flags.hasPronoun &&
      !request.recentDocIds?.length &&
      intentFamily === 'documents' &&
      confidence < CONFIDENCE_THRESHOLDS.CLARIFY_THRESHOLD &&
      request.hasDocuments === false  // Only clarify if user has NO documents at all
    ) {
      // Use BANK-DRIVEN clarifyTemplates
      const langCode = language === 'es' ? 'en' : language;
      const clarifyResult = this.clarifyTemplates.getMissingInfo(
        'no_document_specified',
        langCode as 'en' | 'pt'
      );
      return {
        shouldClarify: true,
        clarifyQuestion: clarifyResult.message,
      };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ChatGPT-like: Even for very low confidence, prefer making a guess
    // Only clarify if confidence is extremely low AND no clear signals
    // ═══════════════════════════════════════════════════════════════════════
    if (
      confidence < CONFIDENCE_THRESHOLDS.CLARIFY_THRESHOLD &&
      !flags.hasPronoun &&
      !flags.hasExplicitFilename &&
      !flags.isFollowup &&
      intentFamily !== 'file_actions' &&
      request.hasDocuments === false
    ) {
      // Very low confidence with no signals and no documents - MAYBE clarify
      // But still prefer not to
      return { shouldClarify: false };
    }

    // Default: don't clarify - make best guess
    return { shouldClarify: false };
  }
}

// Export singleton
export const router = RouterService.getInstance();
